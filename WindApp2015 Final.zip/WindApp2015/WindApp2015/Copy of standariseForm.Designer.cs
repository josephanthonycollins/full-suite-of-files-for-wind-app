﻿namespace WindApp2015
{
    partial class copystandardiseForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.copystandardiselblrows = new System.Windows.Forms.Label();
            this.copystandardiselblcols = new System.Windows.Forms.Label();
            this.copystandardisetxtbrows = new System.Windows.Forms.TextBox();
            this.copystandardisetxtbcols = new System.Windows.Forms.TextBox();
            this.copystandardiseFormbtOk = new System.Windows.Forms.Button();
            this.copystandardiseFormCancel = new System.Windows.Forms.Button();
            this.copystandardiselblh = new System.Windows.Forms.Label();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // copystandardiselblrows
            // 
            this.copystandardiselblrows.AutoSize = true;
            this.copystandardiselblrows.Location = new System.Drawing.Point(71, 84);
            this.copystandardiselblrows.Name = "copystandardiselblrows";
            this.copystandardiselblrows.Size = new System.Drawing.Size(37, 13);
            this.copystandardiselblrows.TabIndex = 0;
            this.copystandardiselblrows.Text = "Rows:";
            // 
            // copystandardiselblcols
            // 
            this.copystandardiselblcols.AutoSize = true;
            this.copystandardiselblcols.Location = new System.Drawing.Point(71, 148);
            this.copystandardiselblcols.Name = "copystandardiselblcols";
            this.copystandardiselblcols.Size = new System.Drawing.Size(50, 13);
            this.copystandardiselblcols.TabIndex = 1;
            this.copystandardiselblcols.Text = "Columns:";
            // 
            // copystandardisetxtbrows
            // 
            this.copystandardisetxtbrows.Location = new System.Drawing.Point(167, 84);
            this.copystandardisetxtbrows.Name = "copystandardisetxtbrows";
            this.copystandardisetxtbrows.Size = new System.Drawing.Size(75, 20);
            this.copystandardisetxtbrows.TabIndex = 0;
            this.copystandardisetxtbrows.Validated += new System.EventHandler(this.standardisetxtbrows_Validated);
            // 
            // standardisetxtbcols
            // 
            this.copystandardisetxtbcols.Location = new System.Drawing.Point(167, 148);
            this.copystandardisetxtbcols.Name = "standardisetxtbcols";
            this.copystandardisetxtbcols.Size = new System.Drawing.Size(75, 20);
            this.copystandardisetxtbcols.TabIndex = 1;
            this.copystandardisetxtbcols.Validated += new System.EventHandler(this.copystandardisetxtbcols_Validated);
            // 
            // copystandardiseFormbtOk
            // 
            this.copystandardiseFormbtOk.Location = new System.Drawing.Point(47, 199);
            this.copystandardiseFormbtOk.Name = "copystandardiseFormbtOk";
            this.copystandardiseFormbtOk.Size = new System.Drawing.Size(106, 36);
            this.copystandardiseFormbtOk.TabIndex = 2;
            this.copystandardiseFormbtOk.Text = "OK";
            this.copystandardiseFormbtOk.UseVisualStyleBackColor = true;
            this.copystandardiseFormbtOk.Click += new System.EventHandler(this.copystandardiseFormbtOk_Click);
            // 
            // copystandardiseFormCancel
            // 
            this.copystandardiseFormCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.copystandardiseFormCancel.Location = new System.Drawing.Point(206, 199);
            this.copystandardiseFormCancel.Name = "copystandardiseFormCancel";
            this.copystandardiseFormCancel.Size = new System.Drawing.Size(106, 36);
            this.copystandardiseFormCancel.TabIndex = 3;
            this.copystandardiseFormCancel.Text = "Cancel";
            this.copystandardiseFormCancel.UseVisualStyleBackColor = true;
            // 
            // copystandardiselblh
            // 
            this.copystandardiselblh.AutoSize = true;
            this.copystandardiselblh.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.copystandardiselblh.Location = new System.Drawing.Point(59, 41);
            this.copystandardiselblh.Name = "copystandardiselblh";
            this.copystandardiselblh.Size = new System.Drawing.Size(281, 13);
            this.copystandardiselblh.TabIndex = 6;
            this.copystandardiselblh.Text = "Grouping: data split into groups of rows*columns";
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // copystandardiseForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.copystandardiseFormCancel;
            this.ClientSize = new System.Drawing.Size(372, 303);
            this.Controls.Add(this.copystandardiselblh);
            this.Controls.Add(this.copystandardiseFormCancel);
            this.Controls.Add(this.copystandardiseFormbtOk);
            this.Controls.Add(this.copystandardisetxtbcols);
            this.Controls.Add(this.copystandardisetxtbrows);
            this.Controls.Add(this.copystandardiselblcols);
            this.Controls.Add(this.copystandardiselblrows);
            this.Name = "copystandardiseForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "standariseForm";
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.Label copystandardiselblrows;
        public System.Windows.Forms.Label copystandardiselblcols;
        public System.Windows.Forms.TextBox copystandardisetxtbrows;
        public System.Windows.Forms.TextBox copystandardisetxtbcols;
        private System.Windows.Forms.Button copystandardiseFormbtOk;
        private System.Windows.Forms.Button copystandardiseFormCancel;
        public System.Windows.Forms.Label copystandardiselblh;
        private System.Windows.Forms.ErrorProvider errorProvider1;


    }
}