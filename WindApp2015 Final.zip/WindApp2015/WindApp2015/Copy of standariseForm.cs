﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindApp2015
{
    //form which will be called by the ARIMA class when the user wants to fit a specific ARMA model (it allows either the p or the q to be 0).

    public partial class copystandardiseForm : Form
    {
        //number of rows in the spreadsheet
        private int n1;

        public int N1
        {
            get { return n1; }
            set { n1 = value; }
        }

        //number of columns in the spreadsheet
        private int m1;

        public int M1
        {
            get { return m1; }
            set { m1 = value; }
        }

        public copystandardiseForm()
        {
            InitializeComponent();
        }

        private void standardisetxtbrows_Validated(object sender, EventArgs e)
        {
            int d;
            bool bTest = int.TryParse(copystandardisetxtbrows.Text, out d);
            if ((bTest == true) && (d <= this.N1) )
                this.errorProvider1.SetError(copystandardisetxtbrows, "");
            else
            {
                string str="This value must be an integer between 0 and "+this.N1;
                this.errorProvider1.SetError(copystandardisetxtbrows, str);
            }
       }

        private void copystandardisetxtbcols_Validated(object sender, EventArgs e)
        {
            int d;
            bool bTest = int.TryParse(copystandardisetxtbcols.Text, out d);
            if ((bTest == true) && (d <= this.M1))
                this.errorProvider1.SetError(copystandardisetxtbcols, "");
            else
            {
                string str = "This value must be an integer between 0 and " + this.M1;
                this.errorProvider1.SetError(copystandardisetxtbcols, str);

            }
        }

        private void copystandardiseFormbtOk_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.OK;
            if ((errorProvider1.GetError(copystandardisetxtbcols).Length != 0) || (errorProvider1.GetError(copystandardisetxtbrows).Length != 0))
            {
                MessageBox.Show("Input must be correct before continuing");
                return;
            }
            this.Close();
        }


        //end of standardise class
    }
}
