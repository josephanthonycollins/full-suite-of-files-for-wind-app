﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WindApp2015
{
    //Class for finding roots, solving differential equations etc.

    class DR
    {
        //we will use this instance to help calculate the inverse of matrices, solve a system of simulataneous equations etc
        system_solver s = new system_solver();

        //Linear Boundary Value Problem - Finite Difference Method
        public double[,] LinFinDiff(double a, double b, int NN, double alpha, double beta, func1 p, func1 q, func1 r)
        {
            /*Solve the linear bvp y'' (x) = p (x) y' (x) + q (x) y (x) + r (x) 
             on the range [a, b] with y (a) = alpha] and y (b) = Beta
             NN is the number of internal node positions*/

            double h = (b - a) / (NN + 1);
            double halfh = h / 2;
            double hsqr = h * h;

            double[] x = new double[NN];
            for (int i = 1; i <= NN; i++)
                x[i - 1] = a + i * h;

            //defining the vectors of the tri-diagonal matrix
            double[] aa = new double[NN];
            double[] bb = new double[NN];
            double[] cc = new double[NN];
            double[] dd = new double[NN];
            for (int i = 0; i < NN; i++)
            {
                aa[i] = 0;
                bb[i] = 0;
                cc[i] = 0;
                dd[i] = 0;
            }

            for (int i = 0; i < NN; i++)
            {
                //define aa
                if (i > 0)
                    aa[i] = -1 - halfh * p(x[i]);

                //define bb
                bb[i] = 2 + hsqr * q(x[i]);

                //define cc
                if (i < NN - 1)
                    cc[i] = -1 + halfh * p(x[i]);

                //define dd
                if (i == 0)
                {
                    dd[i] = -hsqr * r(x[i]) + (1 + halfh * p(x[i])) * alpha;
                }
                else if (i == NN - 1)
                {
                    dd[i] = -hsqr * r(x[i]) + (1 - halfh * p(x[i])) * beta;
                }
                else
                    dd[i] = -hsqr * r(x[i]);
            }

            double[] y = s.ThomasAlg(aa, bb, cc, dd);

            double[,] ans = new double[NN + 2, 2];

            ans[0, 0] = a;
            ans[0, 1] = alpha;
            ans[NN + 1, 0] = b;
            ans[NN + 1, 1] = beta;
            for (int i = 1; i < NN + 1; i++)
            {
                ans[i, 0] = x[i - 1];
                ans[i, 1] = y[i - 1];
            }

            return ans;
            //end of method
        }

        //Non Linear Boundary Value Problem - Finite Difference Method
        public double[,] NonLinFinDiffNewtonRaphson(double a, double b, int NN, double alpha, double beta, funcN f, double toler, int maxiter)
        {
            /*Solve the non - linear bvp y'' (x) = f (x, y, y') on the range [a, b] 
              with y (a) = Alpha and y (b) = Beta*/

            int iter = 1;
            bool cgt = false;

            double dy = 0, dy2 = 0, dy3 = 0, dy4 = 0, dy5 = 0;

            double h = (b - a) / (NN + 1);
            double halfh = h / 2;
            double hsqr = h * h;
            double twoh = 2.0 * h;
            double twohsqr = 2 * hsqr;

            double[] x = new double[NN];
            for (int i = 1; i <= NN; i++)
                x[i - 1] = a + i * h;

            //defining the vectors of the tri-diagonal matrix
            double[] aa = new double[NN];
            double[] bb = new double[NN];
            double[] cc = new double[NN];
            double[] dd = new double[NN];
            double[] yold = new double[NN];
            double[] ynew = new double[NN];


            for (int i = 0; i < NN; i++)
            {
                aa[i] = 0;
                bb[i] = 0;
                cc[i] = 0;
                dd[i] = 0;
                yold[i] = 0;
            }

            double m = (beta - alpha) / (b - a);

            //linear fit through the boundary nodes as an initial approximation
            for (int i = 0; i < NN; i++)
            {
                yold[i] = alpha + m * (x[i] - a);
            }

            while (iter < maxiter)
            {

                //this is the Do loop in the Mathematica code, note that the mathematica
                //code runs from 1 to NN, whereas in C# we run from 0 to NN-1
                for (int j = 0; j < NN; j++)
                {

                    if (j == 0)
                    {
                        dy = yold[j + 1] - alpha;
                        dy2 = dy / twoh;
                        double[] vec = { x[j], yold[j], dy2 };
                        dd[j] = -1.0 * (2.0 * yold[j] - alpha - yold[j + 1] + hsqr * f(vec));
                        dy4 = yold[j + 2] + 2.0 * (alpha - yold[j + 1]) - (alpha - h * ((yold[j] - alpha) / (x[j] - a)));
                    }

                    if (j == 1)
                    {
                        dy = yold[j + 1] - yold[j - 1];
                        dy2 = dy / twoh;
                        double[] vec = { x[j], yold[j], dy2 };
                        dd[j] = -1.0 * (2.0 * yold[j] - yold[j - 1] - yold[j + 1] + hsqr * f(vec));
                        dy4 = yold[j + 2] + 2.0 * (yold[j - 1] - yold[j + 1]) - alpha;
                    }

                    if (j == NN - 2)
                    {
                        dy = yold[j + 1] - yold[j - 1];
                        dy2 = dy / twoh;
                        double[] vec = { x[j], yold[j], dy2 };
                        dd[j] = -1.0 * (2.0 * yold[j] - yold[j - 1] - yold[j + 1] + hsqr * f(vec));
                        dy4 = beta + 2.0 * (yold[j - 1] - yold[j + 1]) - yold[j - 2];
                    }

                    if (j == NN - 1)
                    {
                        dy = beta - yold[j - 1];
                        dy2 = dy / twoh;
                        double[] vec = { x[j], yold[j], dy2 };
                        dd[j] = -1.0 * (2.0 * yold[j] - yold[j - 1] - beta + hsqr * f(vec));
                        dy4 = (beta + h * ((beta - yold[j]) / (b - x[j]))) + 2.0 * (yold[j - 1] - beta) - yold[j - 2];
                    }

                    if ((j >= 2) && (j <= NN - 3))
                    {
                        dy = yold[j + 1] - yold[j - 1];
                        dy2 = dy / twoh;
                        double[] vec = { x[j], yold[j], dy2 };
                        dd[j] = -1.0 * (2.0 * yold[j] - yold[j - 1] - yold[j + 1] + hsqr * f(vec));
                        dy4 = yold[j + 2] + 2.0 * (yold[j - 1] - yold[j + 1]) - yold[j - 2];
                    }

                    dy3 = 0.5 * dy;
                    dy5 = dy4 / twohsqr;
                    double[] tmp1 = { x[j], yold[j], dy2 + dy5 };
                    double[] tmp2 = { x[j], yold[j], dy2 - dy5 };
                    double df1 = f(tmp1) - f(tmp2);
                    double df2 = 0;

                    if (Math.Abs(dy4) < 1E-9)
                    {
                        df2 = 1;
                    }
                    else
                    {
                        df2 = ((halfh * hsqr) / (dy4)) * df1;
                    }

                    //now define the vectors a, b, c that form the Jacobi matrix
                    aa[j] = -1 - df2;
                    double[] tmp3 = { x[j], yold[j] + dy3, dy2 };
                    double[] tmp4 = { x[j], yold[j] - dy3, dy2 };
                    bb[j] = 2.0 + (hsqr / dy) * (f(tmp3) - f(tmp4));
                    cc[j] = -1.0 + df2;
                    //end of for loop
                }

                double[] v = s.ThomasAlg(aa, bb, cc, dd);

                for (int i = 0; i < NN; i++)
                {
                    ynew[i] = yold[i] + v[i];
                }

                double maxnorm = -100000;
                for (int i = 0; i < NN; i++)
                {
                    if (Math.Abs(v[i]) > maxnorm)
                        maxnorm = Math.Abs(v[i]);
                }

                if (maxnorm < toler)
                {
                    cgt = true;
                    break;

                }

                for (int i = 0; i < NN; i++)
                {
                    yold[i] = ynew[i];
                }

                iter = iter + 1;
                //end of while loop
            }

            if (cgt == true)
                Console.Write("\nSolution has converged to within a tolerance eps in {0} iterations\n", iter);
            else
                Console.Write("\nSolution has failed to converge after {0} iterations\n", maxiter);

            double[,] ans = new double[NN + 2, 3];

            ans[0, 0] = a;
            ans[0, 1] = alpha;
            ans[0, 2] = iter;
            ans[NN + 1, 0] = b;
            ans[NN + 1, 1] = beta;
            ans[NN + 1, 2] = iter;
            for (int i = 1; i < NN + 1; i++)
            {
                ans[i, 0] = x[i - 1];
                ans[i, 1] = ynew[i - 1];
                ans[i, 2] = iter;
            }

            return ans;
            //end of method
        }

        //Linear Boundary Value Problem - Quasi Shooting Method
        public double[,] LinShooting(double a, double b, int NN, double alpha, double beta, funcN f11, funcN f21, funcN f12, funcN f22, bool indicator)
        {
            //Solve the linear bvp y'' (x) = p (x) y' (x) + q (x) y (x) + r (x) on the range [a, b] 
            //with y (a) = Alpha and y (b) = Beta 

            //BVP has had the required initial value problem broekn down into
            //four first order equations

            double dx = (b - a) / (NN - 1);

            //Solve the linear IVP y'' (x) = p (x) y' (x) + q (x) y (x) + r (x) 
            //on the range [a, b] with y (a) = Alpha and y' (a) = 0 
            FunctionMatrix f1 = new FunctionMatrix(1, 2);
            f1[0, 0] = f11;
            f1[0, 1] = f21;
            double[] vals1 = { a, alpha, 0 };
            double[,] y1sol = RungeKutta(f1, vals1, dx, a, b + dx);

            //Solve the linear IVP y'' (x) = p (x) y' (x) + q (x) y (x) 
            //on the range [a, b] with y (a) = 0 and y'(a)=1
            FunctionMatrix f2 = new FunctionMatrix(1, 2);
            f2[0, 0] = f12;
            f2[0, 1] = f22;
            double[] vals2 = { a, 0, 1 };
            double[,] y2sol = RungeKutta(f2, vals2, dx, a, b + dx);

            //check to ensure y2(b) is not equal to 0
            double coup = 0;
            int rows2 = y2sol.GetLength(0);
            int rows1 = y1sol.GetLength(0);

            if (y2sol[rows2 - 1, 1] > 1E-9)
            {
                coup = (beta - y1sol[rows1 - 1, 1]) / y2sol[rows2 - 1, 1];
            }
            else
                coup = 0;

            double[,] ans = new double[Math.Min(rows1, rows2), 3];

            if (coup != 0)
            {
                if (indicator == true)
                    Console.Write("\nA unique solution to the BVP has been found.\n");
                for (int i = 0; i < Math.Min(rows1, rows2); i++)
                {
                    ans[i, 0] = y1sol[i, 0];
                    ans[i, 1] = y1sol[i, 1] + coup * y2sol[i, 1];
                    ans[i, 2] = y1sol[i, 2] + coup * y2sol[i, 2];

                }

            }
            else
            {
                if (indicator == true)
                    Console.Write("\nA unique solution to the BVP has not been found.\n");
                for (int i = 0; i < Math.Min(rows1, rows2); i++)
                {
                    ans[i, 0] = y1sol[i, 0];
                    ans[i, 1] = y1sol[i, 1] + coup * y2sol[i, 1];
                    ans[i, 2] = y1sol[i, 2] + coup * y2sol[i, 2];

                }
            }

            return ans;
            //end of method
        }

        //Non Linear Boundary Value Problem - Shooting Method
        public double[,] NonLinShootSecant(double a, double b, int NN, double alpha, double beta, funcN f1, funcN f2, double toler, int maxiter, bool indicator)
        {
            //Solve the non - linear bvp y'' (x) = f (x, y, y') on the range [a, b] 
            //with y (a) = Alpha and y (b) = Beta
            //Assume that f is some function f(x, y, z), 
            //where z = y'(x), its value will be approximated numerically 

            double lr = Math.Max(a, b) - Math.Min(a, b);
            double dx = lr / (NN - 1);
            int iter = 1;
            double t0 = 0, t2 = 0, t1 = 0, dy = 0, dt = 0;
            double[,] tempybvp = null;
            double[,] tempyold = null;
            double[,] tempyolder = null;

            int rows = 0;
            int cols = 0;

            while (iter < maxiter)
            {

                //which statement in the corresponding Mathematica module
                if (iter == 1)
                {
                    t0 = (beta - alpha) / lr;
                    t2 = t0;
                }

                if (iter == 2)
                {
                    rows = tempybvp.GetLength(0);
                    t1 = t0 + (beta - tempybvp[rows - 1, 1]) / lr;
                    t2 = t1;
                }

                if (iter > 2)
                {
                    int r1 = tempyold.GetLength(0);
                    int r2 = tempyolder.GetLength(0);
                    dy = tempyold[r1 - 1, 1] - tempyolder[r2 - 1, 1];
                    if (Math.Abs(dy) > 1E-9)
                    {
                        dt = 1 / dy * (tempyold[r1 - 1, 1] - beta) * (t1 - t0);
                    }
                    else
                    {
                        if (indicator == true)
                            Console.Write("\nAlgorithm is not likely to converge\n");
                        dt = 1;
                        break;
                    }
                    t2 = t1 - dt;
                    t0 = t1;
                    t1 = t2;
                }

                //solve the IVP with the updated value of t
                FunctionMatrix f = new FunctionMatrix(1, 2);
                f[0, 0] = f1;
                f[0, 1] = f2;
                double[] vals = { a, alpha, t2 };
                double[,] ybvp = RungeKutta(f, vals, dx, a, b + dx);
                rows = ybvp.GetLength(0);
                cols = ybvp.GetLength(1);
                tempybvp = new double[rows, cols];
                for (int i = 0; i < rows; i++)
                    for (int j = 0; j < cols; j++)
                        tempybvp[i, j] = ybvp[i, j];

                if (iter == 1)
                {
                    rows = tempybvp.GetLength(0);
                    cols = tempybvp.GetLength(1);
                    tempyolder = new double[rows, cols];
                    for (int i = 0; i < rows; i++)
                        for (int j = 0; j < cols; j++)
                            tempyolder[i, j] = tempybvp[i, j];
                }

                if (iter == 2)
                {
                    rows = tempybvp.GetLength(0);
                    cols = tempybvp.GetLength(1);
                    tempyold = new double[rows, cols];
                    for (int i = 0; i < rows; i++)
                        for (int j = 0; j < cols; j++)
                            tempyold[i, j] = tempybvp[i, j];
                }

                if (iter > 2)
                {
                    int rows1 = tempyold.GetLength(0);
                    int cols1 = tempyold.GetLength(1);
                    tempyolder = new double[rows1, cols1];
                    for (int i = 0; i < rows1; i++)
                        for (int j = 0; j < cols1; j++)
                            tempyolder[i, j] = tempyold[i, j];

                    int rows2 = tempybvp.GetLength(0);
                    int cols2 = tempybvp.GetLength(1);
                    tempyold = new double[rows2, cols2];
                    for (int i = 0; i < rows2; i++)
                        for (int j = 0; j < cols2; j++)
                            tempyold[i, j] = tempybvp[i, j];

                }

                if ((iter > 2) && (Math.Abs(tempybvp[tempybvp.GetLength(0) - 1, 1] - beta) < toler))
                {
                    if (indicator == true)
                        Console.Write("\nThe shooting method has converged to a solution in {0} iterations.\n", iter);
                    break;
                }

                iter = iter + 1;

            }

            return tempybvp;
            //end of method
        }

        //Runge Kutta step
        public double[] RK4Step(FunctionMatrix f, double[] vals, double h)
        {
            int neqns = f.Cols;
            int m = vals.GetLength(0);
            //array to contain the output of the update
            double[] update = new double[m];

            double[] F1 = new double[neqns];
            double[] F2 = new double[neqns];
            double[] F3 = new double[neqns];
            double[] F4 = new double[neqns];

            //Calculating F1i
            for (int i = 0; i < neqns; i++)
            {
                F1[i] = h * f[0, i](vals);
            }

            //next we need to get the updated vector in order to calculate F2i
            double[] f2vals = new double[m];
            f2vals[0] = vals[0] + h / 2;
            for (int i = 1; i < m; i++)
            {
                f2vals[i] = vals[i] + F1[i - 1] / 2;
            }
            //Calculating F2i
            for (int i = 0; i < neqns; i++)
            {
                F2[i] = h * f[0, i](f2vals);
            }

            //next we need to get the updated vector in order to calculate F3i
            double[] f3vals = new double[m];
            f3vals[0] = vals[0] + h / 2;
            for (int i = 1; i < m; i++)
            {
                f3vals[i] = vals[i] + F2[i - 1] / 2;
            }
            //Calculating F3i
            for (int i = 0; i < neqns; i++)
            {
                F3[i] = h * f[0, i](f3vals);
            }

            //next we need to get the updated vector in order to calculate F4i
            double[] f4vals = new double[m];
            f4vals[0] = vals[0] + h;
            for (int i = 1; i < m; i++)
            {
                f4vals[i] = vals[i] + F3[i - 1];
            }
            //Calculating F4i
            for (int i = 0; i < neqns; i++)
            {
                F4[i] = h * f[0, i](f4vals);
            }

            //calculating the update
            update[0] = vals[0] + h;
            for (int i = 1; i < m; i++)
            {
                //update[i]=vals[i]+1/6*(F1[i-1]+2*F2[i-1]+2*F3[i-1]+F4[i-1]);
                update[i] = vals[i] + (1.0 / 6.0) * (F1[i - 1] + 2 * F2[i - 1] + 2 * F3[i - 1] + F4[i - 1]);

            }

            return update;
        }

        public double[,] RungeKutta(FunctionMatrix f, double[] vals, double h, double lower, double upper)
        {
            int steps = (int)((upper - lower) / h);
            int m = vals.GetLength(0);
            double[,] ans = new double[steps, m];
            double[] valsold = new double[m];
            for (int i = 0; i < m; i++)
            {
                valsold[i] = vals[i];
            }
            for (int i = 0; i < steps; i++)
            {
                //add the old vals to the "ans" matrix
                for (int j = 0; j < m; j++)
                {
                    ans[i, j] = valsold[j];
                }

                double[] valsnew = RK4Step(f, valsold, h);

                //now reassign the values
                for (int k = 0; k < m; k++)
                {
                    valsold[k] = valsnew[k];
                }
            }

            //return the answer
            return ans;

            //end of method
        }

        public double[] AB3Step(FunctionMatrix f, double[] vals1, double[] vals2, double[] vals3, double h)
        {
            int neqns = f.Cols;
            int m = vals1.GetLength(0);
            //array to contain the output of the update
            double[] update = new double[m];

            double[] F1 = new double[neqns];
            double[] F2 = new double[neqns];
            double[] F3 = new double[neqns];
            double[] F4 = new double[neqns];

            //Calculating F1i
            for (int i = 0; i < neqns; i++)
            {
                F1[i] = 23.0 * f[0, i](vals1);
            }

            //Calculating F2i
            for (int i = 0; i < neqns; i++)
            {
                F2[i] = 16.0 * f[0, i](vals2);
            }

            //Calculating F3i
            for (int i = 0; i < neqns; i++)
            {
                F3[i] = 5.0 * f[0, i](vals3);
            }

            //calculating the update
            update[0] = vals1[0] + h;
            for (int i = 1; i < m; i++)
            {
                update[i] = vals1[i] + (h / 12.0) * (F1[i - 1] - F2[i - 1] + F3[i - 1]);
            }

            return update;
            //end of method
        }

        public double[,] AB3Solve(FunctionMatrix f, double[] vals, double h, double lower, double upper)
        {
            int steps = (int)((upper - lower) / h);
            int m = vals.GetLength(0);
            double[,] ans = new double[steps, m];

            //Using Runge Kutta to get initial starting points
            double[] v3 = new double[m];
            for (int i = 0; i < m; i++)
            {
                v3[i] = vals[i];
            }
            double[] v2 = RK4Step(f, v3, h);
            double[] v1 = RK4Step(f, v2, h);
            //now add these points to the ans
            for (int i = 0; i < m; i++)
            {
                ans[0, i] = v3[i];
                ans[1, i] = v2[i];
                ans[2, i] = v1[i];
            }

            //now we can start applying the AB3Step
            for (int i = 3; i < steps; i++)
            {
                double[] vupdate = AB3Step(f, v1, v2, v3, h);
                //now add vupdate to the matrix
                for (int j = 0; j < m; j++)
                    ans[i, j] = vupdate[j];
                //now we need to reassign the values
                for (int k = 0; k < m; k++)
                {
                    v3[k] = v2[k];
                    v2[k] = v1[k];
                    v1[k] = vupdate[k];
                }
            }

            return ans;
        }

        public double[] AB4Step(FunctionMatrix f, double[] vals1, double[] vals2, double[] vals3, double[] vals4, double h)
        {
            int neqns = f.Cols;
            int m = vals1.GetLength(0);
            //array to contain the output of the update
            double[] update = new double[m];

            double[] F1 = new double[neqns];
            double[] F2 = new double[neqns];
            double[] F3 = new double[neqns];
            double[] F4 = new double[neqns];

            //Calculating F1i
            for (int i = 0; i < neqns; i++)
            {
                F1[i] = 55.0 * f[0, i](vals1);
            }

            //Calculating F2i
            for (int i = 0; i < neqns; i++)
            {
                F2[i] = -59.0 * f[0, i](vals2);
            }

            //Calculating F3i
            for (int i = 0; i < neqns; i++)
            {
                F3[i] = 37.0 * f[0, i](vals3);
            }

            //Calculating F4i
            for (int i = 0; i < neqns; i++)
            {
                F4[i] = -9.0 * f[0, i](vals4);
            }

            //calculating the update
            update[0] = vals1[0] + h;
            for (int i = 1; i < m; i++)
            {
                update[i] = vals1[i] + (h / 24.0) * (F1[i - 1] + F2[i - 1] + F3[i - 1] + F4[i - 1]);
            }

            return update;
            //end of method
        }

        public double[,] AB4Solve(FunctionMatrix f, double[] vals, double h, double lower, double upper)
        {
            int steps = (int)((upper - lower) / h);
            int m = vals.GetLength(0);
            double[,] ans = new double[steps, m];

            //Using Runge Kutta to get initial starting points
            double[] v4 = new double[m];
            for (int i = 0; i < m; i++)
            {
                v4[i] = vals[i];
            }
            double[] v3 = RK4Step(f, v4, h);
            double[] v2 = RK4Step(f, v3, h);
            double[] v1 = RK4Step(f, v2, h);
            //now add these points to the ans
            for (int i = 0; i < m; i++)
            {
                ans[0, i] = v4[i];
                ans[1, i] = v3[i];
                ans[2, i] = v2[i];
                ans[3, i] = v1[i];
            }

            //now we can start applying the AB4Step
            for (int i = 4; i < steps; i++)
            {
                double[] vupdate = AB4Step(f, v1, v2, v3, v4, h);
                //now add vupdate to the matrix
                for (int j = 0; j < m; j++)
                    ans[i, j] = vupdate[j];
                //now we need to reassign the values
                for (int k = 0; k < m; k++)
                {
                    v4[k] = v3[k];
                    v3[k] = v2[k];
                    v2[k] = v1[k];
                    v1[k] = vupdate[k];
                }
            }

            return ans;
        }

        public double[] AM3Step(FunctionMatrix f, double[] vals1, double[] vals2, double[] vals3, double[] vals4, double h)
        {
            int neqns = f.Cols;
            int m = vals1.GetLength(0);
            //array to contain the output of the update
            double[] update = new double[m];

            double[] F1 = new double[neqns];
            double[] F2 = new double[neqns];
            double[] F3 = new double[neqns];
            double[] F4 = new double[neqns];

            //Calculating F1i
            for (int i = 0; i < neqns; i++)
            {
                F1[i] = 9.0 * f[0, i](vals1);
            }

            //Calculating F2i
            for (int i = 0; i < neqns; i++)
            {
                F2[i] = 19.0 * f[0, i](vals2);
            }

            //Calculating F3i
            for (int i = 0; i < neqns; i++)
            {
                F3[i] = -5.0 * f[0, i](vals3);
            }

            //Calculating F4i
            for (int i = 0; i < neqns; i++)
            {
                F4[i] = f[0, i](vals4);
            }

            //calculating the update
            update[0] = vals2[0] + h;
            for (int i = 1; i < m; i++)
            {
                update[i] = vals2[i] + (h / 24.0) * (F1[i - 1] + F2[i - 1] + F3[i - 1] + F4[i - 1]);
            }

            return update;
            //end of method
        }

        public double[,] ABMSolve(FunctionMatrix f, double[] vals, double h, double lower, double upper)
        {
            int steps = (int)((upper - lower) / h);
            int m = vals.GetLength(0);
            double[,] ans = new double[steps, m];

            //Using Runge Kutta to get initial starting points
            double[] v4 = new double[m];
            for (int i = 0; i < m; i++)
            {
                v4[i] = vals[i];
            }
            double[] v3 = RK4Step(f, v4, h);
            double[] v2 = RK4Step(f, v3, h);
            double[] v1 = RK4Step(f, v2, h);
            //now add these points to the ans
            for (int i = 0; i < m; i++)
            {
                ans[0, i] = v4[i];
                ans[1, i] = v3[i];
                ans[2, i] = v2[i];
                ans[3, i] = v1[i];
            }

            //now we can start applying the algorithm
            for (int i = 4; i < steps; i++)
            {
                double[] vupdate = AB4Step(f, v1, v2, v3, v4, h);
                //now add vupdate to the matrix
                for (int j = 0; j < m; j++)
                    ans[i, j] = vupdate[j];
                double[] vupdatenew = AM3Step(f, vupdate, v1, v2, v3, h);
                //now add vupdatenew to the matrix
                for (int j = 0; j < m; j++)
                    ans[i, j] = vupdatenew[j];


                //now we need to reassign the values
                for (int k = 0; k < m; k++)
                {
                    v4[k] = v3[k];
                    v3[k] = v2[k];
                    v2[k] = v1[k];
                    v1[k] = vupdatenew[k];
                }
            }

            return ans;

        }

        public double[,] RKFStep(FunctionMatrix f, double[] vals, double h)
        {
            int neqns = f.Cols;
            int m = vals.GetLength(0);
            //arrays to contain the output of the update
            double[] update = new double[m];
            double[] updatenew = new double[m];
            double[] R = new double[m];
            double[,] output = new double[3, m];

            double[] F1 = new double[neqns];
            double[] F2 = new double[neqns];
            double[] F3 = new double[neqns];
            double[] F4 = new double[neqns];
            double[] F5 = new double[neqns];
            double[] F6 = new double[neqns];

            //Calculating F1i
            for (int i = 0; i < neqns; i++)
            {
                F1[i] = h * f[0, i](vals);
            }

            //next we need to get the updated vector in order to calculate F2i
            double[] f2vals = new double[m];
            f2vals[0] = vals[0] + h / 4.0;
            for (int i = 1; i < m; i++)
            {
                f2vals[i] = vals[i] + F1[i - 1] / 4.0;
            }
            //Calculating F2i
            for (int i = 0; i < neqns; i++)
            {
                F2[i] = h * f[0, i](f2vals);
            }

            //next we need to get the updated vector in order to calculate F3i
            double[] f3vals = new double[m];
            f3vals[0] = vals[0] + 3.0 * h / 8.0;
            for (int i = 1; i < m; i++)
            {
                f3vals[i] = vals[i] + 3 * F1[i - 1] / 32.0 + 9 * F2[i - 1] / 32.0;
            }
            //Calculating F3i
            for (int i = 0; i < neqns; i++)
            {
                F3[i] = h * f[0, i](f3vals);
            }

            //next we need to get the updated vector in order to calculate F4i
            double[] f4vals = new double[m];
            f4vals[0] = vals[0] + 12.0 * h / 13.0;
            for (int i = 1; i < m; i++)
            {
                f4vals[i] = vals[i] + 1932.0 * F1[i - 1] / 2197.0 - 7200.0 * F2[i - 1] / 2197.0 + 7296.0 * F3[i - 1] / 2197.0;
            }
            //Calculating F4i
            for (int i = 0; i < neqns; i++)
            {
                F4[i] = h * f[0, i](f4vals);
            }

            //next we need to get the updated vector in order to calculate F5i
            double[] f5vals = new double[m];
            f5vals[0] = vals[0] + h;
            for (int i = 1; i < m; i++)
            {
                f5vals[i] = vals[i] + 439.0 * F1[i - 1] / 216.0 - 8.0 * F2[i - 1] + 3680.0 * F3[i - 1] / 513.0 - 845.0 * F4[i - 1] / 4104.0;
            }
            //Calculating F5i
            for (int i = 0; i < neqns; i++)
            {
                F5[i] = h * f[0, i](f5vals);
            }

            //next we need to get the updated vector in order to calculate F6i
            double[] f6vals = new double[m];
            f6vals[0] = vals[0] + h / 2.0;
            for (int i = 1; i < m; i++)
            {
                f6vals[i] = vals[i] - 8.0 * F1[i - 1] / 27.0 + 2.0 * F2[i - 1] - 3544.0 * F3[i - 1] / 2565.0 + 1859.0 * F4[i - 1] / 4104.0 - 11.0 * F5[i - 1] / 40.0;
            }
            //Calculating F6i
            for (int i = 0; i < neqns; i++)
            {
                F6[i] = h * f[0, i](f6vals);
            }

            //calculating the update
            update[0] = vals[0] + h;
            for (int i = 1; i < m; i++)
            {
                update[i] = vals[i] + 25.0 * F1[i - 1] / 216.0 + 1408.0 * F3[i - 1] / 2565.0 + 2197.0 * F4[i - 1] / 4104.0 - F5[i - 1] / 5.0;
            }

            //calculating updatenew
            updatenew[0] = vals[0] + h;
            for (int i = 1; i < m; i++)
            {
                updatenew[i] = vals[i] + 16.0 * F1[i - 1] / 135.0 + 6656.0 * F3[i - 1] / 12825.0 + 28561.0 * F4[i - 1] / 56430.0 - 9 * F5[i - 1] / 50.0 + 2 * F6[i - 1] / 55.0;
            }

            //calculating updatenew
            R[0] = 0;
            for (int i = 1; i < m; i++)
            {
                R[i] = 1 / h * (Math.Abs(F1[i - 1] / 360.0 - 128.0 * F3[i - 1] / 4275.0 - 2197.0 * F4[i - 1] / 75240.0 + F5[i - 1] / 50.0 + 2 * F6[i - 1] / 55.0));
            }

            //updating the output array
            for (int i = 0; i < m; i++)
            {
                output[0, i] = update[i];
                output[1, i] = updatenew[i];
                output[2, i] = R[i];
            }

            return output;
        }

        public double[,] RKFSolve(FunctionMatrix f, double[] vals, double hmin, double hmax, double lower, double upper, double toler)
        {
            double dx = hmax;
            int counter = 0;
            int iter = 1;
            int niter = 0;
            int m = vals.GetLength(0);
            //might need to change the size of the array later on
            double[,] ans = new double[30000, m];

            //add the initial step to the ans array
            for (int i = 0; i < m; i++)
                ans[0, i] = vals[i];

            //we will use this array in the while loop
            double[] valsnew = new double[m];
            for (int i = 0; i < m; i++)
                valsnew[i] = vals[i];


            while ((iter == 1) && (niter < 20000))
            {
                double[] valsold = new double[m];
                for (int i = 0; i < m; i++)
                    valsold[i] = valsnew[i];

                double[,] rklist = RKFStep(f, valsold, dx);
                double maxnorm = 0;
                for (int i = 0; i < m; i++)
                {
                    if (rklist[2, i] > maxnorm)
                        maxnorm = rklist[2, i];
                }
                //error per step is acceptable
                if (maxnorm < toler)
                {
                    counter = counter + 1;
                    for (int i = 0; i < m; i++)
                        valsnew[i] = rklist[0, i];
                    for (int i = 0; i < m; i++)
                        ans[counter, i] = valsnew[i];
                }
                //compute step size conversion factor for next step
                double delta = 0.84 * Math.Pow((toler / maxnorm), 0.25);
                //
                if (delta < 0.1)
                    dx = 0.1 * dx;
                else
                    if (delta > 4)
                        dx = 4.0 * dx;
                    else
                        dx = delta * dx;
                //
                if (dx < hmin)
                    dx = hmin;
                if (dx > hmax)
                    dx = hmax;

                if (ans[counter, 0] > upper)
                    iter = 0;
                if (ans[counter, 0] + dx > upper)
                    iter = 0;

                niter = niter + 1;
            }

            int row = 0;

            //now there might be alot of zeros in the matrix, can we determine where these are
            for (int i = 0; i < ans.GetLength(0); i++)
            {
                double sum = 0;
                for (int j = 0; j < ans.GetLength(1); j++)
                {
                    sum = sum + ans[i, j];
                }
                if (sum == 0)
                {
                    row = i;
                    break;
                }
            }
            //now return only those values which we are interested in
            double[,] output = new double[row, m];
            for (int i = 0; i < row; i++)
            {
                for (int j = 0; j < ans.GetLength(1); j++)
                {
                    output[i, j] = ans[i, j];
                }
            }

            return output;
        }

        public double[,] ABMStepSizeSolve(FunctionMatrix f, double[] vals, double hmin, double hmax, double lower, double upper, double toler)
        {
            double dx = hmax;
            int counter = 3;
            int iter = 1;
            int niter = 0;
            int m = vals.GetLength(0);
            //might need to change the size of the array later on
            double[,] ans = new double[30000, m];

            //Using Runge Kutta to get initial starting points
            double[] v4 = new double[m];
            for (int i = 0; i < m; i++)
            {
                v4[i] = vals[i];
            }
            double[] v3 = RK4Step(f, v4, dx);
            double[] v2 = RK4Step(f, v3, dx);
            double[] v1 = RK4Step(f, v2, dx);
            //now add these points to the ans
            for (int i = 0; i < m; i++)
            {
                ans[0, i] = v4[i];
                ans[1, i] = v3[i];
                ans[2, i] = v2[i];
                ans[3, i] = v1[i];
            }

            while ((iter == 1) && (niter < 20000))
            {
                double[] valsold = AB4Step(f, v1, v2, v3, v4, dx);
                double[] valsnew = AM3Step(f, valsold, v1, v2, v3, dx);
                double[] rklist = new double[m];
                for (int i = 0; i < m; i++)
                {
                    rklist[i] = Math.Abs(valsnew[i] - valsold[i]);
                }
                double maxnorm = 0;
                for (int i = 0; i < m; i++)
                {
                    if (rklist[i] > maxnorm)
                        maxnorm = rklist[i];
                }
                //error per step is acceptable
                if (maxnorm < toler)
                {
                    counter = counter + 1;
                    for (int i = 0; i < m; i++)
                        ans[counter, i] = valsnew[i];
                    //now we need to reassign the values
                    for (int k = 0; k < m; k++)
                    {
                        v4[k] = v3[k];
                        v3[k] = v2[k];
                        v2[k] = v1[k];
                        v1[k] = valsnew[k];
                    }

                }
                //compute step size conversion factor for next step
                double delta = 1.5 * Math.Pow((toler / maxnorm), 0.25);
                //
                if (delta < 0.1)
                    dx = 0.1 * dx;
                else
                    if (delta > 4)
                        dx = 4.0 * dx;
                    else
                        dx = delta * dx;
                //
                if (dx < hmin)
                    dx = hmin;
                if (dx > hmax)
                    dx = hmax;

                if (ans[counter, 0] > upper)
                    iter = 0;
                if (ans[counter, 0] + dx > upper)
                    iter = 0;

                niter = niter + 1;
            }

            int row = 0;

            //now there might be alot of zeros in the matrix, can we determine where these are
            for (int i = 0; i < ans.GetLength(0); i++)
            {
                double sum = 0;
                for (int j = 0; j < ans.GetLength(1); j++)
                {
                    sum = sum + ans[i, j];
                }
                if (sum == 0)
                {
                    row = i;
                    break;
                }
            }
            //now return only those values which we are interested in
            double[,] output = new double[row, m];
            for (int i = 0; i < row; i++)
            {
                for (int j = 0; j < ans.GetLength(1); j++)
                {
                    output[i, j] = ans[i, j];
                }
            }

            return output;
        }

        //method to implement richardardson extrapolation in 1 dimension
        public double derivative(func1 f, double x, double dx)
        {

            if (dx == 0)
            {
                Console.WriteLine("1 dimension Richardson Extrapolation: dx = 0 hence no output produced.");
                return 0;
            }
            else
            {
                int ntab = 10;
                double con = 1.4;
                double con2 = Math.Sqrt(con);
                double big = 1000000;
                double safe = 2.0;
                int i = 0, j = 0;
                double err = 0, errt = 0, fac = 0, hh = 0, ans = 0;
                double[,] a = new double[ntab, ntab];

                hh = dx;

                // first approximation to f'(x)
                a[0, 0] = (f(x + hh) - f(x - hh)) / (2.0 * hh);

                err = big;

                for (i = 1; i < ntab; i++)
                {
                    hh = hh / con;
                    // approximation to f'(x) with smaller step size
                    a[0, i] = (f(x + hh) - f(x - hh)) / (2.0 * hh);

                    fac = con2;

                    // extrapolate the derivative to higher orders without extra function evaluations
                    for (j = 1; j < ntab; j++)
                    {
                        a[j, i] = (a[j - 1, i] * fac - a[j - 1, i - 1]) / (fac - 1.0);

                        fac = con2 * fac;

                        errt = Math.Max(Math.Abs(a[j, i] - a[j - 1, i]), Math.Abs(a[j, i] - a[j - 1, i - 1]));

                        // compute the new error with the error from the previous step
                        if (errt <= err)
                        {
                            err = errt;
                            // update the derivative estimate
                            ans = a[j, i];
                        }

                        //end of j for loop which resides in i loop which resides in else section
                    }

                    // if error has increased significantly stop
                    if (Math.Abs(a[i, i] - a[i - 1, i - 1]) >= safe * err)
                    {
                        break;
                    }
                    //end of i for loop which resides in the else section
                }

                //Console.WriteLine("The value of the derivative is {0}", ans);

                return ans;
            }

            //end of method
        }

        //method to implement richardson extrapolation in n dimension
        public double partial_derivative(funcN f, double[] x, double dx, int n, int dirn)
        {

            if (dx == 0)
            {
                Console.WriteLine("n dimension Richardson Extrapolation: dx = 0 hence no output produced.");
                return 0;
            }
            else
            {
                int ntab = 20;
                double con = 1.4;
                double con2 = Math.Sqrt(con);
                double big = 1000000;
                double safe = 2.0;
                int i = 0, j = 0, k = 0;
                double err = 0, errt = 0, fac = 0, hh = 0, ans = 0;
                double[,] a = new double[ntab, ntab];
                double[] xphh = new double[n + 1];
                double[] xmhh = new double[n + 1];

                hh = dx;

                /*************changed the indexing here************************/
                for (k = 0; k < n; k++)
                {
                    xphh[k] = x[k];
                    xmhh[k] = x[k];
                }
                xphh[dirn] = xphh[dirn] + hh;
                xmhh[dirn] = xmhh[dirn] - hh;

                // first approximation to f'(x)
                a[0, 0] = (f(xphh) - f(xmhh)) / (2.0 * hh);

                err = big;

                for (i = 1; i < ntab; i++)
                {
                    hh = hh / con;

                    /*************changed the indexing here************************/
                    for (k = 0; k < n; k++)
                    {
                        xphh[k] = x[k];
                        xmhh[k] = x[k];
                    }
                    xphh[dirn] = xphh[dirn] + hh;
                    xmhh[dirn] = xmhh[dirn] - hh;

                    // approximation to f'(x) with smaller step size
                    a[0, i] = (f(xphh) - f(xmhh)) / (2.0 * hh);

                    fac = con2;

                    // extrapolate the derivative to higher orders without extra function evaluations
                    for (j = 1; j <= i; j++)
                    {
                        a[j, i] = (a[j - 1, i] * fac - a[j - 1, i - 1]) / (fac - 1.0);
                        fac = con2 * fac;
                        errt = Math.Max(Math.Abs(a[j, i] - a[j - 1, i]), Math.Abs(a[j, i] - a[j - 1, i - 1]));

                        // compute the new error with the error from the previous step
                        if (errt <= err)
                        {
                            err = errt;
                            // update the derivative estimate
                            ans = a[j, i];
                        }

                        //end of j loop which resides in i, which in turn resides in else
                    }

                    // if error has increased significantly stop
                    if (Math.Abs(a[i, i] - a[i - 1, i - 1]) >= safe * err)
                    {
                        break;
                    }

                    //end of i loop which resides in else
                }

                //Console.WriteLine("The value of the derivative is {0}", ans);

                return ans;
                //end of else section
            }

            //end of method
        }

        //method to calculate the Jacobi at for a system of functions at a particular vector
        public double[,] jacobi(FunctionMatrix fmat, double[] x, double dx)
        {
            int rows = fmat.Rows;
            int cols = fmat.Cols;
            int vars = x.GetLength(0);

            //we will assume that FunctionMatrix is always of the form n*1
            double[,] jac = new double[rows, vars];
            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < vars; j++)
                {
                    jac[i, j] = partial_derivative(fmat[i, 0], x, dx, vars, j);
                }

            }
            return jac;
            //end of method
        }

        //method to calculate the root for a system of functions given an initial guess/vector
        public double[] newtonraphson(FunctionMatrix f, double[] x, double toler)
        {
            int maxiter = 1000;
            double err = 10000000;
            int counter = 0;
            int dim = x.GetLength(0);
            int r = f.Rows;
            double[] xn = new double[dim];
            //populating vector xn
            for (int i = 0; i < dim; i++)
                xn[i] = x[i];
            double[] xnp1 = new double[dim];

            while ((counter < maxiter) && (err > toler))
            {
                Vector Fn = f.EvaluateVector(xn);
                //converting to Vector Objects
                Vector Vxn = new Vector(xn);

                //Need to calculate the Jacobi and convert it to a matrix
                double[,] j = jacobi(f, xn, 0.001);
                double[,] jinv = s.find_inverse(j, j.GetLength(0));
                Matrix Jinv = new Matrix(jinv);

                //this is just F(xn)/F'(xn)
                Vector tmp = Jinv * Fn;

                //xnp1 = xn - F(xn)/F'(xn)
                Vector Vxnp1 = Vxn - tmp;

                //what is the size of the err i.e. xnp1-xn
                Vector Diff = Vxnp1 - Vxn;
                err = Diff.maxNorm();
                double[] t = new double[dim];

                xnp1 = (double[])Vxnp1;
                xn = xnp1;
                counter++;
            }

            return xn;
            //end of method
        }

        //method to calculate the inverse of a matrix using the Sherman Morrison formula
        //this method will be utilised in the Broyden method
        public double[,] BroydenAinv(double[,] Ainvold, double[] deltax, double[] deltaF)
        {
            Matrix MAinvold = new Matrix(Ainvold);
            Vector Vdeltax = new Vector(deltax);
            Vector VdeltaF = new Vector(deltaF);
            //placeholder vector, won't be used for anything apart from calling the outer product and dot product Vector methods
            Vector interim = new Vector(1);
            Vector temp = new Vector(interim.dot(MAinvold, VdeltaF));
            Vector u = new Vector(Vdeltax - temp);
            Vector v = new Vector(interim.dot(Vdeltax, MAinvold));
            Matrix numer = new Matrix(interim.outer(u, v));
            double denom = interim.dot(Vdeltax, temp);
            Matrix update = new Matrix(1 / denom * numer);
            Matrix MAinvnew = new Matrix(MAinvold + update);
            double[,] Ainvnew = (double[,])MAinvnew;
            return Ainvnew;
        }

        //method to calculate the root for a system of functions given an initial guess/vector
        public double[] BroydenShermanMorrison(FunctionMatrix f, double[] x, double toler)
        {
            double err = 10000000;
            int counter = 0;
            int dim = x.GetLength(0);
            int r = f.Rows;
            double[] xn = new double[dim];
            //populating vector xn
            for (int i = 0; i < dim; i++)
                xn[i] = x[i];
            double[] xnp1 = new double[dim];

            //first iteration i.e. use Newton Raphson for one iteration, the Inverse of the Jacobi will be used as the Ainv for Broyden
            Vector Fn = f.EvaluateVector(xn);
            Vector Vxn = new Vector(xn);
            //Need to calculate the Jacobi and convert it to a matrix
            double[,] j = jacobi(f, xn, 0.001);
            double[,] jinv = s.find_inverse(j, j.GetLength(0));
            Matrix Jinv = new Matrix(jinv);
            //this is just F(xn)/F'(xn)
            Vector tmp = Jinv * Fn;
            //xnp1 = xn - F(xn)/F'(xn)
            Vector Vxnp1 = Vxn - tmp;
            //what is the size of the err i.e. xnp1-xn
            Vector Vdeltax = Vxnp1 - Vxn;
            err = Vdeltax.maxNorm();
            xnp1 = (double[])Vxnp1;

            Vector placeholder = new Vector(1);

            //we'll use these later                    
            Vector VFnold = f.EvaluateVector(xn);
            Vector VFnew = f.EvaluateVector(xnp1);
            Vector VdeltaF = VFnew - VFnold;
            double[,] Aold = new double[dim, dim];
            double[,] Anew = new double[dim, dim];


            //now we'll start on the Broyden iteration element
            if (err < toler)
                return xn;
            else
            {
                while ((err > toler) && (counter < 1000))
                {
                    if (counter == 0)
                    {
                        Aold = jinv;
                        Anew = BroydenAinv(Aold, (double[])Vdeltax, (double[])VdeltaF);
                    }
                    else
                    {
                        Anew = BroydenAinv(Aold, (double[])Vdeltax, (double[])VdeltaF);
                    }
                    //now update all the variables
                    Vxnp1 = Vxn - placeholder.dot(new Matrix(Anew), VFnew);
                    Vdeltax = Vxnp1 - Vxn;
                    err = Vdeltax.maxNorm();
                    Aold = Anew;
                    VFnold = f.EvaluateVector((double[])Vxn);
                    VFnew = f.EvaluateVector((double[])Vxnp1);
                    VdeltaF = VFnew - VFnold;
                    Vxn = Vxnp1;
                    xn = (double[])Vxn;
                    counter++;
                }
                return xn;
            }
            //end of method
        }

        //method to calculate the root for a system of functions given an initial guess/vector
        //Gradient Descent with Fixed Alpha
        public double[] GradientAlpha(FunctionMatrix f, double[] x, double toler)
        {
            int counter = 0;
            int dim = x.GetLength(0);
            int r = f.Rows;

            double[,] Jmat = new double[r, dim];
            Matrix MJmat = new Matrix(Jmat);
            Vector VFg1 = new Vector(r);
            Vector Vz = new Vector(dim);
            Vector VFg3 = new Vector(r);
            Vector VFg2 = new Vector(r);
            Vector VFgc = new Vector(r);
            Vector VFgnew = new Vector(r);
            Vector Vxnew = new Vector(dim);


            double alpha2 = 0;
            double alpha3 = 0;
            double[] xold = x;
            double[] xnew = new double[dim];
            double g1 = 0;
            double g2 = 0;
            double g3 = 0;
            double gc = 0;
            double gnew = 0;
            double normz = 0;
            double h1 = 0;
            double h2 = 0;
            double h3 = 0;
            double ac = 0;

            do
            {
                VFg1 = f.EvaluateVector(xold);
                g1 = VFg1.Magnitude();

                //calculate the Jacobian
                Jmat = jacobi(f, xold, 0.001);
                //now update the Matrix object which represents the Jacobian
                for (int i = 0; i < r; i++)
                    for (int j = 0; j < dim; j++)
                        MJmat[i, j] = Jmat[i, j];


                Vz = 2 * (MJmat * VFg1);

                normz = Math.Sqrt(Vz.Magnitude());

                if (normz > toler)
                {
                    Vz = (1 / normz) * Vz;
                    alpha3 = 1;

                    VFg3 = f.EvaluateVector((double[])((Vector)xold - (alpha3 * Vz)));
                    g3 = VFg3.Magnitude();

                    while (Math.Abs(g3 - g1) > toler)
                    {
                        alpha3 = 0.5 * alpha3;

                        VFg3 = f.EvaluateVector((double[])((Vector)xold - (alpha3 * Vz)));
                        g3 = VFg3.Magnitude();
                        if (Math.Abs(alpha3) < 0.5 * toler)
                            break;
                    }

                    alpha2 = 0.5 * alpha3;
                    VFg2 = f.EvaluateVector((double[])((Vector)xold - (alpha2 * Vz)));
                    g2 = VFg2.Magnitude();

                    //perform interpolation
                    h1 = (g2 - g1) / alpha2;
                    h2 = (g3 - g2) / (alpha3 - alpha2);
                    h3 = (h2 - h1) / alpha3;
                    ac = 0.5 * (alpha2 - (h1 / h3));

                    VFgc = f.EvaluateVector((double[])((Vector)xold - (ac * Vz)));
                    gc = VFgc.Magnitude();

                    if (gc < g3)
                    {
                        Vxnew = ((Vector)xold) - (ac * Vz);
                        VFgnew = f.EvaluateVector((double[])Vxnew);
                        gnew = VFgnew.Magnitude();
                    }
                    else
                    {
                        Vxnew = ((Vector)xold) - (alpha3 * Vz);
                        VFgnew = f.EvaluateVector((double[])Vxnew);
                        gnew = VFgnew.Magnitude();
                    }

                    //test for convergence
                    if (Math.Abs(gnew - g1) < toler)
                        break;
                    else
                    {
                        xold = (double[])Vxnew;
                        counter++;
                    }

                    //end if
                }



            } while (counter < 100);

            return (double[])Vxnew;
            //end of method
        }

        //end of class
    }


    //end of namespace
}
