﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WindApp2015
{
    //class which will be used when solving multidimensional systems.
    //Will mainly be used when solving AR models using conditional maximum likelihood.
    //See the ARML() method of the statistics class.

    class FunctionMatrix
    {
        private int rows = 0;
        public int Rows
        {
            get { return rows; }

        }
        private int cols = 0;
        public int Cols
        {
            get { return cols; }

        }

        private funcN[,] f;
        public FunctionMatrix(int rows, int cols)
        {
            if (rows >= 1 && cols >= 1)
            {
                this.rows = rows;
                this.cols = cols;
                f = new funcN[rows, cols];
            }
        }
        public funcN this[int row, int col]
        {
            get
            {
                if (row >= 0 && row < rows && col >= 0 && col < cols)
                    return f[row, col];
                else
                    return null;
            }
            set
            {
                if (row >= 0 && row < rows && col >= 0 && col < cols)
                    f[row, col] = value;
            }
        }
        public Matrix EvaluateMatrix(double[] val)
        {
            Matrix tmp = new Matrix(rows, cols);
            int i, j;
            for (i = 0; i < rows; i++)
                for (j = 0; j < cols; j++)
                    tmp[i, j] = f[i, j](val);
            return tmp;
        }
        public Vector EvaluateVector(double[] val)
        {
            Vector tmp = new Vector(rows);
            int i;
            for (i = 0; i < rows; i++)
                tmp[i] = f[i, 0](val);
            return tmp;
        }


        //end of class

    }

    //end of namespace
}
