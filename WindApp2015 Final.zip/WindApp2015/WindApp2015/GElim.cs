﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WindApp2015
{
    //class for solving simulataneous equations using Gaussian Elimination.

    class GElim
    {
        private int rows;

        public int Rows
        {
            get { return rows; }
        }
        private int cols;

        public int Cols
        {
            get { return cols; }
        }

        //"SolverType" is used to specify standard/partial/scaled gaussian elimination
        private int solvertype = 0;
        public int Solvertype
        {
            get { return solvertype; }
            set { solvertype = value; }
        }

        //"r" will be used for row exchange
        private int[] r;

        //"A" is the matrix in the system Ax=b
        private double[,] A;

        //"b" is the vector in the system Ax=b
        private double[] b;

        //Array "solution" will contain the results of solving the system of simultaneous equations Ax=b
        private double[] solution;

        public double[] Solution
        {
            get { return solution; }
            set { solution = value; }
        }

        //Array "mrowelement" will contain the abs max element of each row in Matrix "A", this info will be used in GE with scaled pivoting
        private double[] mrowelement;

        public GElim()
        {
        }

        public GElim(int rows, int cols)
        {
            if (rows > 0)
                this.rows = rows;
            else
                this.rows = 1;
            if (cols > 0)
                this.cols = cols;
            else
                this.cols = 1;
            A = new double[rows, cols];
            b = new double[rows];
            r = new int[rows];
            solution = new double[cols];
            mrowelement = new double[rows];
        }

        //constructor method i.e. initialising the object
        public GElim(double[,] A, double[] b, int solvertype)
        {
            int rank = A.Rank;
            //find the dimensionality of the system
            int rws = A.GetLength(0);
            int cls = A.GetLength(1);
            this.rows = rws;
            this.cols = cls;
            //initialise the relevant variables
            this.A = new double[this.rows, this.cols];
            this.b = new double[this.rows];
            this.r = new int[this.rows];
            this.solution = new double[this.cols];
            this.mrowelement = new double[this.rows];
            //Now populate the arrays
            int i = 0, j = 0;
            for (i = 0; i < this.rows; i++)
                this.b[i] = b[i];
            for (i = 0; i < this.rows; i++)
                for (j = 0; j < this.cols; j++)
                    this.A[i, j] = A[i, j];
            this.Solvertype = solvertype;
            for (i = 0; i < this.rows; i++)
                this.r[i] = i;
        }

        //Method to interchange row i with row j in Matrix "A" and Matrix "b"
        public void ERO1(int i, int j)
        {
            int tmp = 0;
            tmp = this.r[j];
            this.r[j] = this.r[i];
            this.r[i] = tmp;
        }

        //Method to multiply a row in Matrix "A" and Matrix "b" by a constant
        public void ERO2(int row, double val)
        {
            int j = 0;
            for (j = 0; j < this.cols; j++)
            {
                this.A[row, j] = val * this.A[row, j];
                this.b[j] = val * this.b[j];
            }

        }

        //Method to add a multiple of one row to another i.e. A[row2] is replaced by A[row1]*val + A[row2], similarly b[row2] is replaced by b[row1]*val+b[row2] 
        public void ERO3(int row1, double val, int row2)
        {
            double[] tmpA = new double[this.cols];
            double tmpb = 0;
            int i = 0;
            for (i = 0; i < this.cols; i++)
            {
                tmpA[i] = this.A[row1, i] * val;
            }
            tmpb = b[row1] * val;
            for (i = 0; i < this.cols; i++)
            {
                this.A[row2, i] = tmpA[i] + this.A[row2, i];
            }
            b[row2] = tmpb + b[row2];
        }

        //Method to interchange rows if pivot is 0
        //This method will only be called with standard gaussian elimination
        public void checkpivot(int rw, int cl)
        {
            int tmp = rw;
            while (this.A[rw, cl] == 0)
            {
                //we do this as as r[] has index 0,1,2,3....,rows-1
                if (rw >= this.rows)
                    break;
                rw = rw + 1;
            }
            this.ERO1(tmp, rw);
        }

        //Method populates "solution" matrix/vector which satisfies Ax=b 
        //The matrix "A" needs to be in upper triangular matrix form for this to work
        public void backsubstitution()
        {
            int i = 0, j = 0;
            for (i = this.rows - 1; i >= 0; i--)
            {
                this.solution[i] = this.b[r[i]];
                for (j = i + 1; j < this.rows; j++)
                {
                    this.solution[i] = this.solution[i] - this.A[r[i], j] * this.solution[j];
                }

                this.solution[i] = this.solution[i] / this.A[r[i], i];
            }
        }

        //this method helps implement partial pivoting, this method is used in gaussian elimination with partial pivoting
        public void partialpivot(int row, int col)
        {
            double tmp = 0, max = this.A[r[col], col];
            int i = 0, maxrow = col;
            for (i = col; i < this.cols - 1; i++)
            {
                tmp = this.A[r[i + 1], col];
                if (Math.Abs(max) >= Math.Abs(tmp))
                {

                }
                else
                {
                    max = tmp;
                    maxrow = i + 1;
                }
            }
            this.ERO1(col, maxrow);
        }

        //this method helps implement scaled pivoting, this method is used in gaussian elimination with scaled pivoting
        public void scaledpivot(int counter)
        {
            int m = this.cols - counter, n = this.rows - counter, i = 0, j = 0, maxrow = 0;
            double[,] tmpA = new double[m, n];
            double max = 0, tmp = 0, interim = 0;
            //this creates the temporary scaled matrix "tmpA"
            for (i = 0; i < m; i++)
            {
                for (j = 0; j < n; j++)
                {
                    tmpA[i, j] = this.A[r[i + counter], counter + j] / mrowelement[i + counter];
                }
            }
            //we now need to determine the maximum element in column i of matrix "tmpA" i.e. choose the row to pivot on
            for (i = 0; i < m; i++)
            {
                tmp = tmpA[i, 0];
                if (Math.Abs(max) >= Math.Abs(tmp))
                {

                }
                else
                {
                    max = tmp;
                    maxrow = i;
                }
            }
            interim = mrowelement[counter];
            mrowelement[counter] = mrowelement[counter + maxrow];
            mrowelement[counter + maxrow] = interim;
            this.ERO1(counter, counter + maxrow);
        }

        //this method is used to determine the absolute maximum element in each row in matrix "A", it will be used in gausian elimination with scaled pivoting
        public void maxrowelement()
        {
            double tmp = 0, max = 0;
            int i = 0, j = 0;
            for (i = 0; i < this.rows; i++)
            {
                max = 0;
                for (j = 0; j < this.cols; j++)
                {
                    tmp = Math.Abs(this.A[i, j]);
                    if (Math.Abs(tmp) > Math.Abs(max))
                    {
                        max = tmp;
                    }
                    else
                    {
                    }
                }
                this.mrowelement[i] = max;
            }
        }

        //the "solve" method applied to the GElim object will attempt to solve the system of simulataneous equations using the approach specified by the user
        //if the method solves the system of equations True will be returned, otherwise False will be returned
        public bool solve()
        {
            switch (this.Solvertype)
            {
                //this is standard gaussian elimination
                case 1:
                    {
                        int i = 0, j = 0, k = 0;
                        double m = 0.0;
                        for (i = 0, j = 0; (i < this.rows - 1) && (j < this.cols - 1); i++, j++)
                        {
                            //ensures the pivot is non zero
                            this.checkpivot(r[i], j);
                            //the following just ensures the columns underneath the pivot have 0
                            for (k = i + 1; k <= this.rows - 1; k++)
                            {
                                m = -this.A[r[k], j] / this.A[r[i], j];
                                this.ERO3(r[i], m, r[k]);
                            }
                        }
                        this.backsubstitution();
                        break;
                    }

                //this is gaussian elimination with partial pivoting
                case 2:
                    {
                        int i = 0, j = 0, k = 0;
                        double m = 0.0;
                        for (i = 0, j = 0; (i < this.rows - 1) && (j < this.cols - 1); i++, j++)
                        {
                            //apply partial pivoting
                            this.partialpivot(r[i], j);
                            for (k = i + 1; k <= this.rows - 1; k++)
                            {
                                m = -this.A[r[k], j] / this.A[r[i], j];
                                this.ERO3(r[i], m, r[k]);
                            }
                        }
                        this.backsubstitution();
                        break;
                    }

                //this is gaussian eliminatin with scaled pivoting                
                case 3:
                    {
                        int i = 0, j = 0, k = 0;
                        double m = 0.0;
                        //determine the abs max element in each row of matrix "A"
                        this.maxrowelement();
                        for (i = 0, j = 0; (i < this.rows - 1) && (j < this.cols - 1); i++, j++)
                        {
                            //apply scaled pivoting
                            this.scaledpivot(j);
                            for (k = i + 1; k <= this.rows - 1; k++)
                            {
                                m = -this.A[r[k], j] / this.A[r[i], j];
                                this.ERO3(r[i], m, r[k]);
                            }
                        }
                        this.backsubstitution();
                        break;
                    }

                default:
                    break;
            }

            double check = 0;
            for (int i = 0; i < solution.GetLength(0); i++)
                check = check + Math.Abs(solution[i]);
            if (check == 0.0)
                return false;
            else
                return true;
        }

        //end of class
    }

//end of namespace
}
