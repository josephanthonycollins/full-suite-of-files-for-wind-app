﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WindApp2015
{

    //class which will in the ARML() method of the statistics class to solve an AR model
    //the main use of this class is that it generalises the score function
 
    class Likelihood
    {
        //counter object, will be used in conjunction with the relevant likelihood function
        private int counter = 0;

        public int Counter
        {
            get { return counter; }
            set { counter = value; }
        }

        private List<double> info = new List<double>();

        public List<double> Info
        {
            get { return info; }
            set { info = value; }
        }

        //constructor
        public Likelihood(List<double> d, int c)
        {
            this.Counter = c;
            int size = d.Count();
            for (int i = 0; i < size; i++)
                Info.Add(d[i]);
        }
        
        //Given the conditional likelihood of the AR function
        //Take the derivative and set it equal to zero i.e. the Score Equation
        //The following function defines the Score equation for the AR model
       public double ARScorefunction(double[] arr)
        {
            double total = 0;
            int noparams = arr.Length;
           
            for (int i = noparams; i < Info.Count(); i++)
            {
                double m = 0;
                for (int j = 0; j < noparams; j++)
                {
                    m = m - arr[j] * Info[i - j - 1];
                }
                double interim = (Info[i] - m) * Info[i - this.Counter];
                total = total + interim;

            }
            return total;
            //end of method
        }        
        

        //end of class
    }


//end of namespace
}
