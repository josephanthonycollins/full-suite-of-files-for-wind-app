﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

//Joseph Collins
//Student ID: 98718584
//Course: M.Sc. Mathematical Modelling and Scientific Computing
//University College Cork
//Submission Date: 2015

namespace WindApp2015
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new mainForm());
        }
    }
}
