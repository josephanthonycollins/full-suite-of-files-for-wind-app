﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WindApp2015
{
    class Vector
    {
        private int rows;

        public int Rows
        {
            get { return rows; }
        }

        private double[] data;
        public Vector(int rows)
        {
            if (rows > 0)
                this.rows = rows;
            else
                this.rows = 1;
            data = new double[rows];
        }
        public Vector(Vector val)
        {
            rows = val.rows;
            data = new double[rows];
            for (int i = 0; i < rows; i++)
                data[i] = val.data[i];
        }
        public Vector(double[] x)
        {
            rows = x.GetLength(0);
            data = new double[rows];
            for (int i = 0; i < rows; i++)
                data[i] = x[i];
        }
        public static Vector operator +(Vector a, Vector b)
        {
            if (a.rows != b.rows)
                return null;
            Vector tmp = new Vector(a.rows);
            for (int i = 0; i < a.rows; i++)
                tmp.data[i] = a.data[i] + b.data[i];
            return tmp;
        }
        public static Vector operator -(Vector a, Vector b)
        {
            if (a.rows != b.rows)
                return null;
            Vector tmp = new Vector(a.rows);
            for (int i = 0; i < a.rows; i++)
                tmp.data[i] = a.data[i] - b.data[i];
            return tmp;
        }
        public static Vector operator +(Vector a)
        {
            Vector tmp = new Vector(a);
            return tmp;
        }
        public static Vector operator -(Vector a)
        {
            Vector tmp = new Vector(a.rows);
            for (int i = 0; i < a.rows; i++)
                tmp.data[i] = -a.data[i];
            return tmp;
        }
        //scalar product
        public static double operator *(Vector a, Vector b)
        {
            if (a.rows != b.rows)
                return 0;
            Vector tmp = new Vector(a.rows);
            double sum = 0;
            for (int i = 0; i < a.rows; i++)
                sum += a[i] * b[i];
            return sum;
        }
        //scalar product
        public static Vector operator *(double a, Vector b)
        {
            Vector tmp = new Vector(b.rows);
            for (int i = 0; i < b.rows; i++)
                tmp[i] = a * b[i];
            return tmp;
        }

        //Product of Matrix and vector
        public static Vector operator *(Matrix a, Vector b)
        {
            if (a.Cols != b.rows)
                return null;
            int i, j;
            double sum = 0;
            Vector tmp = new Vector(a.Rows);
            for (i = 0; i < a.Rows; i++)
            {
                sum = 0;
                for (j = 0; j < a.Cols; j++)
                    sum += a[i, j] * b[j];
                tmp[i] = sum;
            }
            return tmp;
        }
        public void Output()
        {
            for (int i = 0; i < rows; i++)
            {
                Console.Write("{0,4:F5}\t", data[i]);
            }
            Console.WriteLine();
        }
        public void setValue(int row, double val)
        {
            if (!(row >= 0 && row < rows))
                return;
            data[row] = val;
        }
        public static explicit operator Vector(double d)
        {
            Vector tmp = new Vector(3);
            for (int i = 0; i < 3; i++)
                tmp.data[i] = d;
            return tmp;
        }
        //double array to Vector
        public static explicit operator Vector(double[] val)
        {
            Vector tmp = new Vector(val.Length);
            for (int i = 0; i < val.Length; i++)
                tmp.data[i] = val[i];
            return tmp;
        }
        //vector to a double array
        public static explicit operator double[](Vector val)
        {
            double[] tmp = new double[val.Rows];
            for (int i = 0; i < val.Rows; i++)
                tmp[i] = val[i];
            return tmp;
        }
        //indexer function
        public double this[int rowindex]
        {
            get
            {
                if (rowindex < rows && rowindex >= 0)
                    return data[rowindex];
                else
                    return 0;
            }
            set
            {
                if (rowindex < rows && rowindex >= 0)
                    data[rowindex] = value;
                //else do nothing
            }
        }
        public double maxNorm()
        {
            double max = 0, val;
            for (int i = 0; i < rows; i++)
                if ((val = Math.Abs(data[i])) > max)
                    max = val;
            return max;
        }

        //dot product of two vectors
        public double dot(Vector v1, Vector v2)
        {
            int r1 = v1.Rows;
            int r2 = v2.Rows;
            if (r1 == r2)
            {
                double sum = 0;
                for (int i = 0; i < r1; i++)
                {
                    sum = sum + v1.data[i] * v2.data[i];
                }
                return sum;
            }
            else return 0;
        }
        //dot product of a matrix and a vector
        public Vector dot(Matrix m, Vector v)
        {
            int mrows = m.Rows;
            int mcols = m.Cols;
            int vrows = v.Rows;
            if (mcols == vrows)
            {
                double[] temp = new double[mrows];
                for (int i = 0; i < mrows; i++)
                {
                    double sum = 0;
                    for (int j = 0; j < vrows; j++)
                    {
                        double c = m[i, j] * v[j];
                        sum = sum + m[i, j] * v[j];
                    }
                    temp[i] = sum;
                }
                Vector ans = new Vector(temp);
                return ans;
            }
            else
                return v;
        }
        //dot product of a vector and a Matrix
        public Vector dot(Vector v, Matrix m)
        {
            int mrows = m.Rows;
            int mcols = m.Cols;
            int vrows = v.Rows;
            if (mcols == vrows)
            {
                double[] temp = new double[mrows];
                for (int i = 0; i < mrows; i++)
                {
                    double sum = 0;
                    for (int j = 0; j < vrows; j++)
                    {
                        double c = m[i, j] * v[j];
                        sum = sum + m[i, j] * v[j];
                    }
                    temp[i] = sum;
                }
                Vector ans = new Vector(temp);
                return ans;
            }
            else
                return v;
        }


        //outer productover of two vectors
        //dot product of two vectors
        public Matrix outer(Vector v1, Vector v2)
        {
            int r1 = v1.Rows;
            int r2 = v2.Rows;
            double[,] temp = new double[v1.rows, v2.rows];
            for (int i = 0; i < r1; i++)
            {
                for (int j = 0; j < r2; j++)
                {
                    temp[i, j] = v1.data[i] * v2.data[j];
                }
            }
            Matrix m = new Matrix(temp);
            return m;
        }

        //returns the magnitude of the 
        public double Magnitude()
        {
            double sum = 0;
            for (int i = 0; i < this.Rows; i++)
            {
                sum = sum + data[i] * data[i];
            }
            return sum;
        }

        //end of class
    }

//end of namespace
}
