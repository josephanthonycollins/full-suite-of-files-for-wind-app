﻿namespace WindApp2015
{
    partial class ARIMA
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend2 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.ARIMALoadbt = new System.Windows.Forms.Button();
            this.ARIMAlb = new System.Windows.Forms.ListBox();
            this.ARIMAac1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.ARIMAdiff = new System.Windows.Forms.Button();
            this.ARIMAac2 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            ((System.ComponentModel.ISupportInitialize)(this.ARIMAac1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ARIMAac2)).BeginInit();
            this.SuspendLayout();
            // 
            // ARIMALoadbt
            // 
            this.ARIMALoadbt.Location = new System.Drawing.Point(29, 26);
            this.ARIMALoadbt.Name = "ARIMALoadbt";
            this.ARIMALoadbt.Size = new System.Drawing.Size(123, 48);
            this.ARIMALoadbt.TabIndex = 0;
            this.ARIMALoadbt.Text = "Load Data";
            this.ARIMALoadbt.UseVisualStyleBackColor = true;
            this.ARIMALoadbt.Click += new System.EventHandler(this.ARIMALoadbt_Click);
            // 
            // ARIMAlb
            // 
            this.ARIMAlb.FormattingEnabled = true;
            this.ARIMAlb.Location = new System.Drawing.Point(29, 107);
            this.ARIMAlb.Name = "ARIMAlb";
            this.ARIMAlb.Size = new System.Drawing.Size(259, 121);
            this.ARIMAlb.TabIndex = 1;
            this.ARIMAlb.SelectedValueChanged += new System.EventHandler(this.ARIMAlb_SelectedValueChanged_1);
            // 
            // ARIMAac1
            // 
            this.ARIMAac1.BackColor = System.Drawing.SystemColors.ButtonFace;
            chartArea1.AxisX.MajorGrid.Enabled = false;
            chartArea1.AxisX.MajorTickMark.Enabled = false;
            chartArea1.AxisX.Title = "Lag";
            chartArea1.AxisY.MajorGrid.Enabled = false;
            chartArea1.Name = "ChartArea1";
            this.ARIMAac1.ChartAreas.Add(chartArea1);
            legend1.DockedToChartArea = "ChartArea1";
            legend1.Name = "Legend1";
            legend1.ShadowColor = System.Drawing.Color.White;
            this.ARIMAac1.Legends.Add(legend1);
            this.ARIMAac1.Location = new System.Drawing.Point(336, 26);
            this.ARIMAac1.Name = "ARIMAac1";
            series1.ChartArea = "ChartArea1";
            series1.Legend = "Legend1";
            series1.Name = "Series1";
            this.ARIMAac1.Series.Add(series1);
            this.ARIMAac1.Size = new System.Drawing.Size(398, 265);
            this.ARIMAac1.TabIndex = 2;
            this.ARIMAac1.Text = "chart1";
            // 
            // ARIMAdiff
            // 
            this.ARIMAdiff.Location = new System.Drawing.Point(768, 26);
            this.ARIMAdiff.Name = "ARIMAdiff";
            this.ARIMAdiff.Size = new System.Drawing.Size(110, 47);
            this.ARIMAdiff.TabIndex = 3;
            this.ARIMAdiff.Text = "Differencing";
            this.ARIMAdiff.UseVisualStyleBackColor = true;
            this.ARIMAdiff.Click += new System.EventHandler(this.ARIMAdiff_Click);
            // 
            // ARIMAac2
            // 
            this.ARIMAac2.BackColor = System.Drawing.SystemColors.ButtonFace;
            chartArea2.AxisX.MajorGrid.Enabled = false;
            chartArea2.AxisX.MajorTickMark.Enabled = false;
            chartArea2.AxisX.Title = "Lag";
            chartArea2.AxisY.MajorGrid.Enabled = false;
            chartArea2.Name = "ChartArea1";
            this.ARIMAac2.ChartAreas.Add(chartArea2);
            legend2.DockedToChartArea = "ChartArea1";
            legend2.Name = "Legend1";
            legend2.ShadowColor = System.Drawing.Color.White;
            this.ARIMAac2.Legends.Add(legend2);
            this.ARIMAac2.Location = new System.Drawing.Point(927, 26);
            this.ARIMAac2.Name = "ARIMAac2";
            series2.ChartArea = "ChartArea1";
            series2.Legend = "Legend1";
            series2.Name = "Series1";
            this.ARIMAac2.Series.Add(series2);
            this.ARIMAac2.Size = new System.Drawing.Size(398, 265);
            this.ARIMAac2.TabIndex = 4;
            this.ARIMAac2.Text = "chart1";
            // 
            // ARIMA
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.ClientSize = new System.Drawing.Size(1354, 629);
            this.Controls.Add(this.ARIMAac2);
            this.Controls.Add(this.ARIMAdiff);
            this.Controls.Add(this.ARIMAac1);
            this.Controls.Add(this.ARIMAlb);
            this.Controls.Add(this.ARIMALoadbt);
            this.Name = "ARIMA";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "ARIMA";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.ARIMA_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ARIMAac1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ARIMAac2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button ARIMALoadbt;
        private System.Windows.Forms.ListBox ARIMAlb;
        private System.Windows.Forms.DataVisualization.Charting.Chart ARIMAac1;
        private System.Windows.Forms.Button ARIMAdiff;
        private System.Windows.Forms.DataVisualization.Charting.Chart ARIMAac2;
    }
}