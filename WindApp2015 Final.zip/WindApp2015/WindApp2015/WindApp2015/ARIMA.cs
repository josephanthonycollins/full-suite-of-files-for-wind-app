﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using Excel = Microsoft.Office.Interop.Excel;
using System.Data.OleDb;
using System.Windows.Forms.DataVisualization.Charting;
using NsExcel = Microsoft.Office.Interop.Excel;

namespace WindApp2015
{
    public partial class ARIMA : Form
    {
        //filename
        private String fn;

        public String Fn
        {
            get { return fn; }
            set { fn = value; }
        }

        private Statistics p;

        internal Statistics P
        {
            get { return p; }
            set { p = value; }
        }

        //location of all the files which will be shown in the listbox
        private List<String> flocations = new List<string>();

        public List<String> Flocations
        {
            get { return flocations; }
            set { flocations = value; }
        }

        //worksheet names of the spreadsheet that is being loaded
        private List<String> tab = new List<string>();

        public List<String> Tab
        {
            get { return tab; }
            set { tab = value; }
        }

        //spreadsheet names
        private List<String> fnames = new List<string>();

        public List<String> Fnames
        {
            get { return fnames; }
            set { fnames = value; }
        }

        //this list will contain the time series info, it is populated by the user selecting an item in the "explrlb" listbox
        private List<double> tseries = new List<double>();

        public List<double> Tseries
        {
            get { return tseries; }
            set { tseries = value; }
        }

        //this variable will contain the number of rows in the underlying tab that we are interested in
        private int r = 0;

        public int R
        {
            get { return r; }
            set { r = value; }
        }

        //this variable will contain the number of rows in the underlying tab that we are interested in
        private int c = 0;

        public int C
        {
            get { return c; }
            set { c = value; }
        }

        public ARIMA()
        {
            InitializeComponent();
        }

        //this is the method that is executed when we click on the "Load Data" button in the ARIMA form
        private void ARIMALoadbt_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.Cursor old = this.Cursor;
            this.Cursor = Cursors.AppStarting;

            //full file location and name
            String strfl;
            //file name and extensions
            String strfilename;
            Stream myStream = null;
            using (OpenFileDialog openFileDialog1 = new OpenFileDialog())
            {
                openFileDialog1.InitialDirectory = "D:\\JC Masters\\Thesis\\Data";
                openFileDialog1.Filter = "Excel files (*.xls or .xlsx)|.xls;*.xlsx";
                openFileDialog1.FilterIndex = 2;
                openFileDialog1.RestoreDirectory = true;
                bool b = true;
                if (openFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    //try and use the openFileDialog1 info
                    try
                    {
                        //NOT 100% SURE THIS IS THE BEST APPROACH, THE WORK AROUND WILL GET THE INFO EVEN IF THE EXCEL FILE IS ALREADY OPEN
                        if (b/*(myStream = openFileDialog1.OpenFile()) != null*/)
                        {
                            //This using statement is now superfluous
                            using (myStream)
                            {
                                strfl = openFileDialog1.FileName;
                                strfilename = openFileDialog1.SafeFileName;
                                this.Fn = strfl;
                                //now populate the list box
                                this.populatelistbox(strfl, strfilename);
                            }
                        }
                    }

                        //if there is an error with using the info from the openFileDialog1 button, report it
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: Could not read file from disk. Original error: " + ex.Message);
                    }

                    //end of if section
                }
            }

            this.Cursor = old;

            //end of ARIMAbt_Click method
        }


        //this method is used to populate ARIMAlb in the ARIMA form
        public void populatelistbox(String s, String q)
        {
            System.Windows.Forms.Cursor old = this.Cursor;
            this.Cursor = Cursors.AppStarting;

            String loc = s;
            String f = q;
            OleDbConnection con = null;
            DataTable dt = null;
            string CconnectionString;
            CconnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + loc + ";Extended Properties=Excel 12.0;";
            con = new OleDbConnection(CconnectionString);

            try
            {
                con.Open();
                dt = con.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);

                String[] excelSheetNames = new String[dt.Rows.Count];
                int i = 0;

                foreach (DataRow row in dt.Rows)
                {

                    excelSheetNames[i] = row["TABLE_NAME"].ToString();
                    Fnames.Add(f);
                    Flocations.Add(loc);
                    Tab.Add(row["TABLE_NAME"].ToString());
                    ARIMAlb.Items.Add(f + " , " + excelSheetNames[i]);
                    i++;
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show("Could not read tab names. Error: " + ex.Message);
            }
            finally
            {
                con.Close();
                this.Cursor = old;
            }

        }

        //this method allows the user to click on the ARIMAlb and select the data they wish examine, it populate the TSeries list,
        //it will also call the HookUpData method
        private void ARIMAlb_SelectedValueChanged_1(object sender, EventArgs e)
        {
            System.Windows.Forms.Cursor old = this.Cursor;
            this.Cursor = Cursors.AppStarting;

            //next we want to remove any data that may already be in the Tseries object
            Tseries.Clear();

            int position = ARIMAlb.SelectedIndex;
            string curItem = Tab[position];
            string df = Flocations[position];
            string f = ";Extended Properties=\"Excel 12.0;HDR=NO\"";
            string c = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + df + f;
            DataSet data = new DataSet();
            OleDbConnection con = new OleDbConnection(c);
            //var
            DataTable dataTable = new DataTable();
            string query = string.Format("SELECT * FROM [{0}]", curItem);
            OleDbDataAdapter adapter = new OleDbDataAdapter(query, con);
            try
            {
                con.Open();
                adapter.Fill(dataTable);
                data.Tables.Add(dataTable);

                //now we populate Tseries
                int m = 0, n = 0;
                m = data.Tables[0].Rows.Count;
                n = dataTable.Columns.Count;
                this.R = m;
                this.C = n;
                int q = 0, r = 0;
                try
                {
                    for (q = 0; q < m; q++)
                    {
                        for (r = 0; r < n; r++)
                        {

                            double d = (double)data.Tables[0].Rows[q].ItemArray[r];
                            Tseries.Add(d);
                        }
                    }
                    //this enables us to populate the explrTS chart and populate statistics
                    HookUpData();
                }
                catch (Exception x)
                {
                    MessageBox.Show("No data in the underlying tab. Error:" + x.Message);
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show("The listbox selection did not work. Error: " + ex.Message);
            }

            finally
            {
                con.Close();
                this.Cursor = old;
            }

            //end of ARIMAlb_SelectedValueChanged method


        }

        //method to populate the autocorrelation and partial autocorrelation functions
        public void HookUpData()
        {
            System.Windows.Forms.Cursor old = this.Cursor;
            this.Cursor = Cursors.AppStarting;

            this.show();

            //if you pick an alternative tab, then you want the ACF and PACF for the previous differenced data set to be hidden
            ARIMAac2.Hide();

            this.P = new Statistics(Tseries);

            //calculate the autcorrelation and partial autocorrelation of the data
            List<double> sac = P.sampleautocorrelation(P.D, 50);
            List<double> spac = P.samplepartialautocorrelation(P.D, 50);

            //plot of the autcoorrelation
            ARIMAac1.Titles.Clear();
            ARIMAac1.Titles.Add(new Title("Sample ACF and PACF", Docking.Top, new Font("Verdana", 8f, FontStyle.Bold), Color.Black));
            ARIMAac1.ChartAreas[0].AxisY.LabelStyle.Font = ARIMAac1.ChartAreas[0].AxisX.LabelStyle.Font = new Font("Arial", 11, GraphicsUnit.Pixel);
            ARIMAac1.Series.Clear();
            var series1 = new System.Windows.Forms.DataVisualization.Charting.Series
            {
                Name = "ACF",
                Color = System.Drawing.Color.Blue,
                IsVisibleInLegend = true,
                IsXValueIndexed = true,
                ChartType = SeriesChartType.Column
            };
            this.ARIMAac1.Series.Add(series1);
            int z = 0;
            foreach (double dd in sac)
            {
                series1.Points.AddXY(z, sac[z]);
                z++;
            }
            var series2 = new System.Windows.Forms.DataVisualization.Charting.Series
            {
                Name = "PACF",
                Color = System.Drawing.Color.Red,
                IsVisibleInLegend = true,
                IsXValueIndexed = true,
                ChartType = SeriesChartType.Column
            };
            this.ARIMAac1.Series.Add(series2);
            z = 0;
            foreach (double dd in spac)
            {
                series2.Points.AddXY(z, spac[z]);
                z++;
            }

            ARIMAac1.Invalidate();
            ARIMAac1.ChartAreas[0].AxisY.Maximum = 1;

            /**************************TESTING***************************************************************************************************/
            List<double> est = P.yulewalker(P.D, 2);
            List<double> resid = P.yulewalkerresiduals(P.D, est);
            List<double> rtest = P.HannanRissanenresiduals(P.D, est, 2, 0);

            Double[,] a = { { 1, 2, 3 }, { 4, 5, 6 } };
            Matrix m = new Matrix(a);
            Matrix mt = m.TransposeMatrix();

            double[,] expl = { { 1, 1,1 }, { 1, 2,3 }, { 1, 4,9 } };
            double[] obs = { 1, 2, 3 };
            double[] output = P.leastsquares(expl, obs);

            //List<double> e = P.HannanRissanen(5, 0, 40);
            //List<double> h = P.HannanRissanen(1, 1, 40);
            List<double> g = P.HannanRissanen(2, 0, 40);
            //List<double> q = P.HannanRissanen(0, 2, 40);
            List<double> ll = P.HannanRissanen(2, 2, 40);
            List<double> zz = P.HannanRissanen(5, 0, 40);
            List<double> qq = P.HannanRissanen(5, 2, 20);
            List<double> e = P.HannanRissanen(5, 2, 40);
            List<double> f = P.HannanRissanen(5, 2, 80);



            /**************************TESTING*********************************************************************************************/            
            this.Cursor = old;

            //end of HookUpData method
        }

        //hide the charts etc
        public void hide()
        {
            ARIMAac1.Hide();
            ARIMAdiff.Hide();
            ARIMAac2.Hide();
        }

        //show the charts etc
        public void show()
        {
            ARIMAac1.Show();
            ARIMAdiff.Show();

        }

        private void ARIMA_Load(object sender, EventArgs e)
        {
            this.hide();
        }

        private void ARIMAdiff_Click(object sender, EventArgs e)
        {
            standardiseForm f1 = new standardiseForm();

            //we don't need all the info from the "standardiseForm" hence we can hide some of objects in the form
            f1.standardisetxtbcols.Text = "1";
            f1.standardisetxtbcols.Visible = false;
            f1.standardiselblcols.Visible = false;
            f1.standardiselblh.Text = "Provide an Integer to specify the differencing:";
            f1.standardiselblrows.Text = "Integer";
            f1.N1 = 100;
            f1.M1 = 100;
            
            //display the dialog
            if (f1.ShowDialog() == DialogResult.OK)
            {
                //need to figure out the number of rows and number of columns in the underlying spreadsheet
                int m2;
                bool m2Test = int.TryParse(f1.standardisetxtbcols.Text, out m2);
                int n2;
                bool n2Test = int.TryParse(f1.standardisetxtbrows.Text, out n2);
                if ((n2 > 0))
                {
                    //display the chart
                    ARIMAac2.Show();
                    this.P.DifferencedData.Clear();
                    this.P.Diff = n2;
                    //now difference the data
                    P.difference();
                    //calculate the autcorrelation and partial autocorrelation of the data
                    List<double> sc = P.sampleautocorrelation(P.DifferencedData, 50);
                    List<double> spc = P.samplepartialautocorrelation(P.DifferencedData, 50);

                    //plot of the autcoorrelation
                    ARIMAac2.Titles.Clear();
                    ARIMAac2.Titles.Add(new Title("Differenced Data: ACF and PACF", Docking.Top, new Font("Verdana", 8f, FontStyle.Bold), Color.Black));
                    ARIMAac2.ChartAreas[0].AxisY.LabelStyle.Font = ARIMAac2.ChartAreas[0].AxisX.LabelStyle.Font = new Font("Arial", 11, GraphicsUnit.Pixel);

                    //plot the TSeries data in the explrTS chart
                    ARIMAac2.Series.Clear();
                    var series3 = new System.Windows.Forms.DataVisualization.Charting.Series
                    {
                        Name = "ACF",
                        Color = System.Drawing.Color.Blue,
                        IsVisibleInLegend = true,
                        IsXValueIndexed = true,
                        ChartType = SeriesChartType.Column
                    };
                    this.ARIMAac2.Series.Add(series3);
                    int z = 0;
                    foreach (double dd in sc)
                    {
                        series3.Points.AddXY(z, sc[z]);
                        z++;
                    }
                    var series4 = new System.Windows.Forms.DataVisualization.Charting.Series
                    {
                        Name = "PACF",
                        Color = System.Drawing.Color.Red,
                        IsVisibleInLegend = true,
                        IsXValueIndexed = true,
                        ChartType = SeriesChartType.Column
                    };
                    this.ARIMAac2.Series.Add(series4);
                    z = 0;
                    foreach (double dd in spc)
                    {
                        series4.Points.AddXY(z, spc[z]);
                        z++;
                    }

                    ARIMAac2.Invalidate();
                    ARIMAac2.ChartAreas[0].AxisY.Maximum = 1;

                    //this.Cursor = old;
                }
                else
                {
                    //ensure that the Diff is set to 0 as the user has decided not to use differencing
                    this.P.Diff = 0;
                }
            }
            /**************************TESTING*********************************************************************************************/   
            List<double> ma5 = P.HannanRissanen(2, 2, 20);
            List<double> ma6 = P.HannanRissanen(0, 2, 20);
            List<double> residtest = P.HannanRissanenresiduals(P.DifferencedData, ma6, 0, 2);
            /**************************TESTING*********************************************************************************************/   

            //end of method
        }


        

        //end of ARIMA class
    }

//end of namespace
}
