﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Excel = Microsoft.Office.Interop.Excel;

namespace WindApp2015
{
    class Statistics
    {
        //this variable will contain data upon which the calculations, transformations etc will be called
        private List<Double> d = new List<double>();

        public List<Double> D
        {
            get { return d; }
            set { d = value; }
        }

        //attribute to hold the bins upon which the explrhist1 chart in explrForm will be based
        private List<Double> histBins = new List<double>();

        public List<Double> HistBins
        {
            get { return histBins; }
            set { histBins = value; }
        }

        //attribute to hold the values upon which the explrhist1 chart in explrForm will be based
        private List<Double> histValues = new List<double>();

        public List<Double> HistValues
        {
            get { return histValues; }
            set { histValues = value; }
        }

        //attribute to hold the bins upon which the explrhist1 chart in explrForm will be based
        private List<Double> wBins = new List<double>();

        public List<Double> WBins
        {
            get { return wBins; }
            set { wBins = value; }
        }

        //attribute to hold the values upon which the explrhist1 chart in explrForm will be based
        private List<Double> wValues = new List<double>();

        public List<Double> WValues
        {
            get { return wValues; }
            set { wValues = value; }
        }

        //this attribute will be populated by the histogramBins() method, it specifies the number of bins in the explrhist1 chart
        //in explrForm
        private int noBins = 0;

        public int NoBins
        {
            get { return noBins; }
            set { noBins = value; }
        }

        //attribute to hold the bins upon which the chart in explrForm will be based
        private List<Double> tBins = new List<double>();

        public List<Double> TBins
        {
            get { return tBins; }
            set { tBins = value; }
        }

        //attribute to hold the values upon which the chart in explrForm will be based
        private List<Double> tValues = new List<double>();

        public List<Double> TValues
        {
            get { return tValues; }
            set { tValues = value; }
        }

        //weibull scale parameter, associated with the weibull_parameter_estimate() method
        private double wScale = 0;

        public double WScale
        {
            get { return wScale; }
            set { wScale = value; }
        }

        //weibull shape parameter, associated with the weibull_parameter_estimate() method
        private double wShape = 0;

        public double WShape
        {
            get { return wShape; }
            set { wShape = value; }
        }

        //this variable will contain the transformed data once the initial exploratory analysis has been performed
        private List<Double> transformedData = new List<double>();

        public List<Double> TransformedData
        {
            get { return transformedData; }
            set { transformedData = value; }
        }

        //this variable will contain the standarised version of the transformed data
        private List<Double> standardisedtransformedData = new List<double>();

        public List<Double> StandardisedTransformedData
        {
            get { return standardisedtransformedData; }
            set { standardisedtransformedData = value; }
        }

        //if the data is transformed and then standarised, this variable will contain the means of each grouping
        private List<Double> stdMeans = new List<double>();

        public List<Double> StdMeans
        {
            get { return stdMeans; }
            set { stdMeans = value; }
        }

        //if the data is transformed and then standarised, this variable will contain the standard deviation of each grouping
        private List<Double> stdStdev = new List<double>();

        public List<Double> StdStdev
        {
            get { return stdStdev; }
            set { stdStdev = value; }
        }

        //number of rows in the transformed and standardised data
        private int n2 = 0;

        public int N2
        {
            get { return n2; }
            set { n2 = value; }
        }

        //number of columns in the transformed and standardised data
        private int m2 = 0;

        public int M2
        {
            get { return m2; }
            set { m2 = value; }
        }


        //null constructor
        public Statistics()
        {
        }

        //constructor
        public Statistics(List<double> data)
        {
            this.D = data;
        }

        //copy constructor
        public Statistics(Statistics stats)
        {
            this.D = stats.D;
        }


        //method to calculate the average
        public double avg(List<double> lst)
        {
            double a = 0;
            int s = 0;
            int counter = 0;
            double total = 0;
            s = lst.Count;
            for (counter = 0; counter < s; counter++)
            {
                total = total + lst[counter];
            }
            a = total / s;
            return a;
        }

        //method to calculate the median
        public double median(List<double> lst)
        {
            double a = 0;
            int s = 0;
            s = lst.Count;
            lst.Sort();
            if (s % 2 == 1)
                a = lst[((s + 1) / 2) - 1];
            else
                a = lst[(s / 2) - 1];
            return a;
        }


        //method to calculate the standard deviation
        public double stdev(List<double> lst)
        {
            double a = 0;
            double b = 0;
            int s = 0;
            int counter = 0;
            double total = 0;
            s = lst.Count;
            b = avg(lst);
            for (counter = 0; counter < s; counter++)
            {
                total = total + (lst[counter] - b) * (lst[counter] - b);
            }
            a = Math.Sqrt(total / (s - 1));
            return a;
        }

        //method to calculate the skewness
        public double skew(List<double> lst)
        {
            double a = 0;
            double b = 0;
            double c = 0;
            int s = 0;
            int counter = 0;
            double total = 0;
            s = lst.Count;
            b = avg(lst);
            c = stdev(lst);
            for (counter = 0; counter < s; counter++)
            {
                total = total + (lst[counter] - b) * (lst[counter] - b) * (lst[counter] - b);
            }
            a = total / (s * c * c * c);
            return a;
        }

        //method to calculate the kurtosis
        public double kurt(List<double> lst)
        {
            double a = 0;
            double b = 0;
            double c = 0;
            int s = 0;
            int counter = 0;
            double total = 0;
            s = lst.Count;
            b = avg(lst);
            c = stdev(lst);
            for (counter = 0; counter < s; counter++)
            {
                total = total + (lst[counter] - b) * (lst[counter] - b) * (lst[counter] - b) * (lst[counter] - b);
            }
            a = total / (s * c * c * c * c);
            return a;
        }

        //method to calculate the maximum
        public double maximum(List<double> lst)
        {
            double a = 0;
            int s = 0;
            int counter = 0;
            s = lst.Count;
            a = lst[0];
            for (counter = 1; counter < s; counter++)
            {
                if (a < lst[counter])
                    a = lst[counter];
            }
            return a;
        }

        //method to calculate the minimum
        public double minimum(List<double> lst)
        {
            double a = 0;
            int s = 0;
            int counter = 0;
            s = lst.Count;
            a = lst[0];
            for (counter = 1; counter < s; counter++)
            {
                if (a > lst[counter])
                    a = lst[counter];
            }
            return a;
        }

        //method to determine the point which is closest to zero
        public double closestzero(List<double> lst)
        {
            double a = 0;
            int s = 0;
            int counter = 0;
            s = lst.Count;
            a = lst[0];
            for (counter = 1; counter < s; counter++)
            {
                if (Math.Abs(a) > Math.Abs(lst[counter]))
                    a = lst[counter];
            }
            return a;
        }


        //method to calculate the bins for any histogram
        //sets the attribute NoBins to 50
        public List<double> histogramBins(List<double> lst)
        {
            List<double> bins = new List<double>();
            //assuming that the number of bins is 40
            NoBins = 50;
            int counter = 0;
            for (counter = 0; counter < NoBins; counter++)
            {
                bins.Add(0);
            }
            //now we populate the HistValues list
            double ml = minimum(lst);
            double mu = maximum(lst);
            double bucketSize = (mu - ml) / NoBins;
            //now we populate the HistBins list
            for (counter = 0; counter < NoBins; counter++)
            {
                /******************************************I think this should be +ml to start the binning at the minimum value*****/
                bins[counter] = bucketSize * counter + ml;
            }
            return bins;
            //end of method
        }

        //method to calculate the frequency of the bins for any histogram
        public List<double> histogramValues(List<double> lst, List<double> bins)
        {
            List<double> values = new List<double>();
            int counter = 0;
            for (counter = 0; counter < NoBins; counter++)
            {
                values.Add(0);
            }
            //now we populate the HistValues list
            double ml = minimum(lst);
            double mu = maximum(lst);
            double bucketSize = (mu - ml) / NoBins;
            foreach (double v in lst)
            {
                int bucketIndex = 0;
                if (bucketSize > 0.0)
                {
                    bucketIndex = (int)((v - ml) / bucketSize);
                    if (bucketIndex == NoBins)
                    {
                        bucketIndex--;
                    }
                }
                values[bucketIndex]++;
            }
            return values;
            //end of method
        }

        //this method will estimate the optimum scale and shape parameters for a Weibull distribution
        //given a dataset
        public void weibull_parameter_estimate(List<double> lst, double init, int iterations)
        {
            int n = lst.Count();
            double[] matA = new double[n];
            double[] matB = new double[n];
            double[] matC = new double[n];
            double[] matD = new double[n];
            int i = 0, j = 0, k = 0, m = 0;
            n = lst.Count();
            for (i = 0; i < iterations; i++)
            {
                double s = 0, sp = 0, lobs = 0, f = 0, dfx = 0, dsp = 0, update = 0, l = 0;
                int z = 0;
                foreach (double d in lst)
                {
                    matA[z] = Math.Pow(d, init);
                    s = s + matA[z];
                    z++;
                }

                z = 0;
                foreach (double e in lst)
                {
                    matB[z] = Math.Log(e);
                    lobs = lobs + matB[z];
                    z++;
                }

                z = 0;
                foreach (double a in matA)
                {
                    matC[z] = a * matB[z];
                    sp = sp + matC[z];
                    z++;
                }

                z = 0;
                foreach (double b in matB)
                {
                    matD[z] = b * b * matA[z];
                    dsp = dsp + matD[z];
                    z++;
                }

                f = (sp / s) - (1 / init) - (1 / (double)n) * lobs;
                dfx = 1 / (init * init) - (sp * sp) / (s * s) + dsp / s;
                update = init - f / dfx;
                init = update;
            }
            this.WShape = init;

            //we have the shape parameter, now to estimate the scale parameter
            double[] matE = new double[n];
            double tot = 0;
            k = 0;
            foreach (double a in lst)
            {
                matE[k] = Math.Pow(a, this.WShape);
                tot = tot + matE[k];
                k++;
            }
            double scale = 0;
            scale = tot / n;
            scale = Math.Pow(scale, 1 / this.WShape);
            this.WScale = scale;

            //end of weibull_parameter_estimate() method
        }

        //method is designed to come with a good initial approximation for the shape parameter of a weibull distribution
        //once a starting value is provided, another algorithm can provide a better update
        public double weibull_initial_guess(List<double> lst)
        {
            int n = lst.Count();
            double s = this.stdev(lst);
            double m = this.avg(lst);
            double val = s / m;
            val = Math.Pow(val, -1.086);
            return val;
            //end of weibull_initial_guess
        }

        //method to generate a weibull sample
        public List<double> weibull_sample(double size, double shape, double scale)
        {
            List<double> wsample = new List<double>();
            Random r = new Random();
            double y = 0, x = 0, w = 0, val = 0;
            int counter = 0;
            for (counter = 0; counter < (int)size; counter++)
            {
                y = r.NextDouble();
                x = -Math.Log(y);
                w = Math.Pow(x, 1 / shape);
                val = w * scale;
                wsample.Add(val);
            }
            return wsample;
            //end of weibull_sample
        }

        //method to generate a normal sample
        public List<double> normal_sample(double size, double m, double s)
        {
            List<double> nsample = new List<double>();
            Random ran = new Random();
            double y = 0, r = 0, u1 = 0, u2 = 0, theta = 0, val = 0;
            int counter = 0;
            for (counter = 0; counter < (int)size; counter++)
            {
                u1 = ran.NextDouble();
                u2 = ran.NextDouble();
                r = Math.Sqrt(-2 * Math.Log(u1));
                theta = 2 * Math.PI * u2;
                val = m + s * r * Math.Sin(theta);
                nsample.Add(val);
            }
            return nsample;
            //end of normal_sample
        }

        //method to determine via an iterative procedure what is the optimum transformation
        //for the underlying data
        public List<double> iterative_measurement(List<double> steps, List<double> lst)
        {
            List<double> tempA = new List<double>();
            List<double> tempB = new List<double>();
            double mean = 0, med = 0, sd = 0, d = 0, val = 0;
            int i = 0, j = 0, counter = 0, size = 0;
            size = steps.Count();
            for (counter = 0; counter < size; counter++)
            {
                d = steps[counter];
                if (tempA.Count() > 0)
                    tempA.Clear();
                foreach (double b in lst)
                {
                    tempA.Add(Math.Pow(b, d));
                }
                mean = this.avg(tempA);
                med = this.median(tempA);
                sd = this.stdev(tempA);
                val = (mean - med) / sd;
                tempB.Add(val);

            }
            return tempB;
            //end of method
        }

        //this generates a list from min to max in steps of (max-min)/intervals, note that 0 is dropped from the list
        public List<double> gen_list(double min, double max, double no_intervals)
        {
            List<double> tempA = new List<double>();
            int counter = 0;
            double d = (max - min) / no_intervals;
            for (counter = 0; counter <= no_intervals; counter++)
            {
                tempA.Add(d * counter + min);
            }
            //if the list contains the value of 0, then drop it
            tempA.RemoveAll(item => item == 0.0);
            return tempA;
            //end of method
        }

        //method to generate the pdf of a normal distribution given the mean, standard deviation and x vals
        public List<double> normal_pdf(double mean, double sd, List<double> xvalues)
        {
            List<double> probs = new List<double>();
            double r = 1 / (sd * Math.Sqrt(2.0 * Math.PI));
            double theta = 0;
            double val = 0;
            foreach (double inc in xvalues)
            {
                theta = -(inc - mean) * (inc - mean) / (2 * sd * sd);
                val = r * Math.Exp(theta);
                probs.Add(val);
            }
            return probs;
            //end of normal_pdf () method
        }

        //method to generate the pdf of a weibull distribution given the shape, scale and x vals
        public List<double> weibull_pdf(double shape, double scale, List<double> xvalues)
        {
            List<double> probs = new List<double>();
            double r = 0;
            double theta = 0;
            double val = 0;
            foreach (double inc in xvalues)
            {
                r = (shape / scale) * (Math.Pow((inc / scale), (shape - 1)));
                theta = Math.Exp(-Math.Pow((inc / scale), shape));
                val = r * theta;
                probs.Add(val);
            }
            return probs;
            //end of weibull_pdf () method
        }

        //pdf given a set of data and x vals
        public List<double> pdf(List<double> sample, List<double> xvalues)
        {
            List<double> probs = histogramValues(sample, xvalues);
            double obs = sample.Count();
            int z = 0;
            for (z = 0; z < xvalues.Count(); z++)
            {
                probs[z] = probs[z] / obs;
            }
            return probs;
            //end of pdf () method
        }

        //method to standarise data
        public void standardise(List<double> sample, double n1, double m1, double n2, double m2)
        {
            this.M2 = (int)m2;
            this.N2 = (int)n2;
            //clear any values that may be in the StandardisedTransformedData list
            if (StandardisedTransformedData.Count() > 0)
                StandardisedTransformedData.Clear();

            List<List<double>> blocks = new List<List<double>>();
            List<double> standardiseddata = new List<double>();
            int i = 0, k = 0, j = 0, l = 0;

            //The following helps to create subblocks on which we calculate the means and standarddeviations
            double index;
            for (k = 0; k < (int)(n1 - (n1 % n2)) / n2; k++)
            {

                for (j = 1; j <= (int)m1 / m2; j++)
                {
                    List<double> subblock = new List<double>();
                    for (i = 1; i <= n2; i++)
                    {
                        //we do this to replicate the Range method in mathematica
                        for (l = 1; l <= m2; l++)
                        {
                            index = ((j - 1) * m2 + l) + (i - 1) * (m1);
                            index = index + k * n2 * m1;
                            subblock.Add(sample[(int)(index - 1)]);
                            //end of l loop
                        }
                        //end of i loop
                    }
                    blocks.Add(subblock);
                    //end of j loop
                }
                //end of k loop
            }

            //at this stage we have the data split into blocks, now we need to calculate the mean of and standard deviation of each block
            int size = blocks.Count();
            List<double> means = new List<double>();
            List<double> stdeviations = new List<double>();
            foreach (List<double> dd in blocks)
            {
                double a = avg(dd);
                double s = stdev(dd);
                means.Add(a);
                stdeviations.Add(s);
            }
            //now we populate the list so that the info will be available elsewhere
            if (StdMeans.Count() > 0)
            {
                StdMeans.Clear();
                StdStdev.Clear();
            }
            foreach (double qr in means)
                StdMeans.Add(qr);
            foreach (double qs in stdeviations)
                StdStdev.Add(qs);


            //now we want to take each observation and subtract the appropriate mean and divide the result by the appropriate standard deviation
            blocks.Clear();
            List<double> temp = new List<double>();
            foreach (double dd in sample)
                temp.Add(dd);
            for (k = 0; k < (int)(n1 - (n1 % n2)) / n2; k++)
            {
                for (j = 1; j <= (int)m1 / m2; j++)
                {
                    List<double> subblock = new List<double>();
                    for (i = 1; i <= n2; i++)
                    {
                        for (l = 1; l <= m2; l++)
                        {
                            index = ((j - 1) * m2 + l) + (i - 1) * (m1);
                            index = index + k * n2 * m1;
                            subblock.Add(sample[(int)(index - 1)]);
                            //end of l loop
                        }
                        //end of i loop
                    }
                    blocks.Add(subblock);
                    double me = avg(subblock);
                    double sd = stdev(subblock);
                    for (i = 1; i <= n2; i++)
                    {
                        for (l = 1; l <= m2; l++)
                        {
                            index = ((j - 1) * m2 + l) + (i - 1) * (m1);
                            index = index + k * n2 * m1;
                            temp[(int)(index - 1)] = (sample[(int)(index - 1)] - me) / sd;
                            //end of l loop
                        }
                        //end of i loop
                    }

                }
                //end of k loop
            }

            //now add the transformed data to the StandardisedTransformedData list which will store the results
            int counter = (int)StdMeans.Count() * (int)n2 * (int)m2;
            for (int g = 0; g < counter; g++)
                StandardisedTransformedData.Add(temp[g]);

            //end of standardise () method
        }

        //method to calculate the sample autocovariance out to lag n
        public List<double> sampleautocovariance(List<double> sample, int lag)
        {
            List<double> sc = new List<double>();
            int size = sample.Count();
            double total=0;
            double mean = avg(sample);
            
            //get autocovariance at lag 0
            for (int i = 0; i < size; i++)
            {
                total=total+(sample[i]-mean)*(sample[i]-mean);

            }
            double ac0 = total / size;
            sc.Add(ac0);

            //get autocovariance at lags>0
            for (int i = 1; i <= lag; i++)
            {
                total = 0;
                //get autocovariance at lag 0
                for (int j = 0; j < size-i; j++)
                {
                    total = total+(sample[j+i] - mean) * (sample[j] - mean);
                }
                double ac = total / size;
                sc.Add(ac);
            }

            return sc;

            //end of sampleautocovariance() method
        }

        //method to calculate the sample autocovariance out to lag n
        public List<double> sampleautocorrelation(List<double> sample, int lag)
        {
            List<double> sa = new List<double>();
            List<double> sc = sampleautocovariance(sample, lag);
            double autoc = 0;
            //get autocovariance at lag 0
            for (int i = 0; i <=lag; i++)
            {
                autoc=sc[i]/sc[0];
                sa.Add(autoc);

            }
            return sa;

            //end of sampleautocorrelation() method
        }

        //method to calculate the sample partialautocorrelation out to lag n
        //this is based on Durbin relations
        public List<double> samplepartialautocorrelation(List<double> sample, int lag)
        {
            List<double> sac = sampleautocorrelation(sample, lag+1);
            List<double> spac = new List<double>();
            double [,] mat= new double[lag+1,lag+1];
            double[] vals = new double[5]{1, 0.003, 0.024, -0.033, 0.069};
            //PACF1=ACF1
            mat[1,1]=sac[1];

            //PACF0=1
            spac.Add(1);

            for (int i = 2; i < lag+1; i++)
            {
                for (int j = i; j > 0; j--)
                {
                    double total = 0;

                    if (j == i)
                    {
                        for (int k = 1; k <= i - 1; k++)
                            total = total + mat[i - 1, k] * sac[i - k];

                        mat[i, i] = (sac[i] - total) / (1 - total);
                    }
                    else
                        mat[i, j] = mat[i - 1, j] - mat[i, i] * mat[i - 1, i - j];

                }
            }

            for (int i = 1; i <= lag-1; i++)
            spac.Add(mat[i,i]);
            return spac;

            //end of sampleautopartialcorrelation() method
        }





        //end of statistics class
    }





    //end of namespace
}
