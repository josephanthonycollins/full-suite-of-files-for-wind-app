﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;

//TO DO NEXT
//(11) Finish off standarise method (what to do about points which are negative), decide how to present the data i.e. plot
//(12) Allow the user to save down the data
//(13) Instead of some of the histograms, would a pdf plot look better?

//ARMA FORM
//(1)Can we come up with a nice graphing method
//(2)Calculate the autocovariances, the autocorrelatinos and the partial autocorrelations
//(3)Plot the aforementioned properties

//Exploratory Section
//maximise the screen and general layout
//Do the graphs need to be changed

namespace WindApp2015
{
    public partial class mainForm : Form
    {
        public mainForm()
        {
            InitializeComponent();
        }

        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void exploratoryAnalysisToolStripMenuItem_Click(object sender, EventArgs e)
        {
            explrForm exploratory = new explrForm();
            exploratory.MdiParent = this;
            //Statistics stats = new Statistics();
            //BindingSource bs = new BindingSource();
            //frmdata.HookUpData(data);
            exploratory.WindowState = FormWindowState.Maximized;
            exploratory.Show();
        }
    }
}
