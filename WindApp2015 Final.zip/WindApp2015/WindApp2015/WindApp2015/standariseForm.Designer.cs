﻿namespace WindApp2015
{
    partial class standardiseForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.standardiselblrows = new System.Windows.Forms.Label();
            this.standardiselblcols = new System.Windows.Forms.Label();
            this.standardisetxtbrows = new System.Windows.Forms.TextBox();
            this.standardisetxtbcols = new System.Windows.Forms.TextBox();
            this.standardiseFormbtOk = new System.Windows.Forms.Button();
            this.standardiseFormCancel = new System.Windows.Forms.Button();
            this.standardiselblh = new System.Windows.Forms.Label();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // standardiselblrows
            // 
            this.standardiselblrows.AutoSize = true;
            this.standardiselblrows.Location = new System.Drawing.Point(71, 84);
            this.standardiselblrows.Name = "standardiselblrows";
            this.standardiselblrows.Size = new System.Drawing.Size(37, 13);
            this.standardiselblrows.TabIndex = 0;
            this.standardiselblrows.Text = "Rows:";
            // 
            // standardiselblcols
            // 
            this.standardiselblcols.AutoSize = true;
            this.standardiselblcols.Location = new System.Drawing.Point(71, 148);
            this.standardiselblcols.Name = "standardiselblcols";
            this.standardiselblcols.Size = new System.Drawing.Size(50, 13);
            this.standardiselblcols.TabIndex = 1;
            this.standardiselblcols.Text = "Columns:";
            // 
            // standardisetxtbrows
            // 
            this.standardisetxtbrows.Location = new System.Drawing.Point(167, 84);
            this.standardisetxtbrows.Name = "standardisetxtbrows";
            this.standardisetxtbrows.Size = new System.Drawing.Size(75, 20);
            this.standardisetxtbrows.TabIndex = 0;
            this.standardisetxtbrows.Validated += new System.EventHandler(this.standardisetxtbrows_Validated);
            // 
            // standardisetxtbcols
            // 
            this.standardisetxtbcols.Location = new System.Drawing.Point(167, 148);
            this.standardisetxtbcols.Name = "standardisetxtbcols";
            this.standardisetxtbcols.Size = new System.Drawing.Size(75, 20);
            this.standardisetxtbcols.TabIndex = 1;
            this.standardisetxtbcols.Validated += new System.EventHandler(this.standardisetxtbcols_Validated);
            // 
            // standardiseFormbtOk
            // 
            this.standardiseFormbtOk.Location = new System.Drawing.Point(47, 199);
            this.standardiseFormbtOk.Name = "standardiseFormbtOk";
            this.standardiseFormbtOk.Size = new System.Drawing.Size(106, 36);
            this.standardiseFormbtOk.TabIndex = 2;
            this.standardiseFormbtOk.Text = "OK";
            this.standardiseFormbtOk.UseVisualStyleBackColor = true;
            this.standardiseFormbtOk.Click += new System.EventHandler(this.standardiseFormbtOk_Click);
            // 
            // standardiseFormCancel
            // 
            this.standardiseFormCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.standardiseFormCancel.Location = new System.Drawing.Point(206, 199);
            this.standardiseFormCancel.Name = "standardiseFormCancel";
            this.standardiseFormCancel.Size = new System.Drawing.Size(106, 36);
            this.standardiseFormCancel.TabIndex = 3;
            this.standardiseFormCancel.Text = "Cancel";
            this.standardiseFormCancel.UseVisualStyleBackColor = true;
            // 
            // standardiselblh
            // 
            this.standardiselblh.AutoSize = true;
            this.standardiselblh.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.standardiselblh.Location = new System.Drawing.Point(59, 41);
            this.standardiselblh.Name = "standardiselblh";
            this.standardiselblh.Size = new System.Drawing.Size(281, 13);
            this.standardiselblh.TabIndex = 6;
            this.standardiselblh.Text = "Grouping: data split into groups of rows*columns";
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // standardiseForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.standardiseFormCancel;
            this.ClientSize = new System.Drawing.Size(372, 303);
            this.Controls.Add(this.standardiselblh);
            this.Controls.Add(this.standardiseFormCancel);
            this.Controls.Add(this.standardiseFormbtOk);
            this.Controls.Add(this.standardisetxtbcols);
            this.Controls.Add(this.standardisetxtbrows);
            this.Controls.Add(this.standardiselblcols);
            this.Controls.Add(this.standardiselblrows);
            this.Name = "standardiseForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "standariseForm";
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label standardiselblrows;
        private System.Windows.Forms.Label standardiselblcols;
        public System.Windows.Forms.TextBox standardisetxtbrows;
        public System.Windows.Forms.TextBox standardisetxtbcols;
        private System.Windows.Forms.Button standardiseFormbtOk;
        private System.Windows.Forms.Button standardiseFormCancel;
        private System.Windows.Forms.Label standardiselblh;
        private System.Windows.Forms.ErrorProvider errorProvider1;


    }
}