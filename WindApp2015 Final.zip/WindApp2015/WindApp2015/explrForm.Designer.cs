﻿namespace WindApp2015
{
    partial class explrForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend2 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea3 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend3 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series3 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea4 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend4 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series4 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea5 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend5 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series5 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea6 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend6 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series6 = new System.Windows.Forms.DataVisualization.Charting.Series();
            this.explrbt = new System.Windows.Forms.Button();
            this.explrlb = new System.Windows.Forms.ListBox();
            this.explrdgv1 = new System.Windows.Forms.DataGridView();
            this.explrTS = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.explrhist1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.explrFormlb1 = new System.Windows.Forms.Label();
            this.explrFormlb2 = new System.Windows.Forms.Label();
            this.explrFormlb3 = new System.Windows.Forms.Label();
            this.explrFormlb4 = new System.Windows.Forms.Label();
            this.explrFormlb5 = new System.Windows.Forms.Label();
            this.explrFormlb6 = new System.Windows.Forms.Label();
            this.explrFormlb7 = new System.Windows.Forms.Label();
            this.explrFormlb8 = new System.Windows.Forms.Label();
            this.explrFormlb9 = new System.Windows.Forms.Label();
            this.explrFormlb10 = new System.Windows.Forms.Label();
            this.explrFormlb11 = new System.Windows.Forms.Label();
            this.explrFormlb12 = new System.Windows.Forms.Label();
            this.explrFormlb13 = new System.Windows.Forms.Label();
            this.explrFormlb14 = new System.Windows.Forms.Label();
            this.explrFormlb15 = new System.Windows.Forms.Label();
            this.explrFormlb16 = new System.Windows.Forms.Label();
            this.explrFormlb17 = new System.Windows.Forms.Label();
            this.explrFormitrb = new System.Windows.Forms.RadioButton();
            this.explrFormwrb = new System.Windows.Forms.RadioButton();
            this.explrFormpl = new System.Windows.Forms.Panel();
            this.explrFormlb25 = new System.Windows.Forms.Label();
            this.explrFormM = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.explrFormhist2 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.explrFormQQ = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.explrFormstandardisebt = new System.Windows.Forms.Button();
            this.explrFormMeans = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.transformedlbl = new System.Windows.Forms.Label();
            this.transformedskewlbl = new System.Windows.Forms.Label();
            this.transformedkurtlbl = new System.Windows.Forms.Label();
            this.transformedskewval = new System.Windows.Forms.Label();
            this.transformedkurtval = new System.Windows.Forms.Label();
            this.standardisedlbl = new System.Windows.Forms.Label();
            this.standardisedskewlbl = new System.Windows.Forms.Label();
            this.standardisedkurtlbl = new System.Windows.Forms.Label();
            this.standardisedskewval = new System.Windows.Forms.Label();
            this.standardisedkurtval = new System.Windows.Forms.Label();
            this.explrFormSavebt = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.explrdgv1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.explrTS)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.explrhist1)).BeginInit();
            this.explrFormpl.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.explrFormM)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.explrFormhist2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.explrFormQQ)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.explrFormMeans)).BeginInit();
            this.SuspendLayout();
            // 
            // explrbt
            // 
            this.explrbt.Location = new System.Drawing.Point(22, 42);
            this.explrbt.Name = "explrbt";
            this.explrbt.Size = new System.Drawing.Size(98, 36);
            this.explrbt.TabIndex = 0;
            this.explrbt.Text = "Load Data";
            this.explrbt.UseVisualStyleBackColor = true;
            this.explrbt.Click += new System.EventHandler(this.explrbt_Click);
            // 
            // explrlb
            // 
            this.explrlb.FormattingEnabled = true;
            this.explrlb.Location = new System.Drawing.Point(22, 88);
            this.explrlb.Name = "explrlb";
            this.explrlb.Size = new System.Drawing.Size(240, 95);
            this.explrlb.TabIndex = 1;
            this.explrlb.SelectedValueChanged += new System.EventHandler(this.explrlb_SelectedValueChanged);
            // 
            // explrdgv1
            // 
            this.explrdgv1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCellsExceptHeader;
            this.explrdgv1.ColumnHeadersHeight = 30;
            this.explrdgv1.Location = new System.Drawing.Point(22, 194);
            this.explrdgv1.Name = "explrdgv1";
            this.explrdgv1.RowHeadersWidth = 25;
            this.explrdgv1.Size = new System.Drawing.Size(240, 150);
            this.explrdgv1.TabIndex = 2;
            // 
            // explrTS
            // 
            this.explrTS.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.explrTS.BorderlineColor = System.Drawing.SystemColors.ButtonFace;
            chartArea1.AlignmentOrientation = ((System.Windows.Forms.DataVisualization.Charting.AreaAlignmentOrientations)((System.Windows.Forms.DataVisualization.Charting.AreaAlignmentOrientations.Vertical | System.Windows.Forms.DataVisualization.Charting.AreaAlignmentOrientations.Horizontal)));
            chartArea1.AxisX.MajorGrid.Enabled = false;
            chartArea1.AxisX.Title = "Observation";
            chartArea1.AxisX.TitleFont = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            chartArea1.AxisY.MajorGrid.Enabled = false;
            chartArea1.AxisY.Title = "Value";
            chartArea1.AxisY.TitleFont = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            chartArea1.BackSecondaryColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            chartArea1.BorderColor = System.Drawing.Color.Transparent;
            chartArea1.Name = "ChartArea1";
            this.explrTS.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.explrTS.Legends.Add(legend1);
            this.explrTS.Location = new System.Drawing.Point(285, 54);
            this.explrTS.Name = "explrTS";
            series1.ChartArea = "ChartArea1";
            series1.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series1.IsVisibleInLegend = false;
            series1.Legend = "Legend1";
            series1.Name = "Series1";
            this.explrTS.Series.Add(series1);
            this.explrTS.Size = new System.Drawing.Size(378, 300);
            this.explrTS.TabIndex = 3;
            this.explrTS.Text = "Data";
            // 
            // explrhist1
            // 
            this.explrhist1.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.explrhist1.BorderlineColor = System.Drawing.SystemColors.ButtonFace;
            chartArea2.AlignmentOrientation = ((System.Windows.Forms.DataVisualization.Charting.AreaAlignmentOrientations)((System.Windows.Forms.DataVisualization.Charting.AreaAlignmentOrientations.Vertical | System.Windows.Forms.DataVisualization.Charting.AreaAlignmentOrientations.Horizontal)));
            chartArea2.AxisX.MajorGrid.Enabled = false;
            chartArea2.AxisX.Title = "Bin";
            chartArea2.AxisX.TitleFont = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            chartArea2.AxisY.MajorGrid.Enabled = false;
            chartArea2.AxisY.Title = "Frequency";
            chartArea2.AxisY.TitleFont = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            chartArea2.BackColor = System.Drawing.Color.White;
            chartArea2.Name = "ChartArea1";
            this.explrhist1.ChartAreas.Add(chartArea2);
            legend2.Name = "Legend1";
            this.explrhist1.Legends.Add(legend2);
            this.explrhist1.Location = new System.Drawing.Point(660, 54);
            this.explrhist1.Name = "explrhist1";
            series2.ChartArea = "ChartArea1";
            series2.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Area;
            series2.IsValueShownAsLabel = true;
            series2.IsVisibleInLegend = false;
            series2.Legend = "Legend1";
            series2.Name = "Series1";
            this.explrhist1.Series.Add(series2);
            this.explrhist1.Size = new System.Drawing.Size(378, 300);
            this.explrhist1.TabIndex = 4;
            this.explrhist1.Text = "chart1";
            // 
            // explrFormlb1
            // 
            this.explrFormlb1.AutoSize = true;
            this.explrFormlb1.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.explrFormlb1.Location = new System.Drawing.Point(1109, 54);
            this.explrFormlb1.Name = "explrFormlb1";
            this.explrFormlb1.Size = new System.Drawing.Size(133, 13);
            this.explrFormlb1.TabIndex = 5;
            this.explrFormlb1.Text = "Summary Statistics";
            // 
            // explrFormlb2
            // 
            this.explrFormlb2.AutoSize = true;
            this.explrFormlb2.Location = new System.Drawing.Point(1109, 80);
            this.explrFormlb2.Name = "explrFormlb2";
            this.explrFormlb2.Size = new System.Drawing.Size(37, 13);
            this.explrFormlb2.TabIndex = 6;
            this.explrFormlb2.Text = "Mean:";
            // 
            // explrFormlb3
            // 
            this.explrFormlb3.AutoSize = true;
            this.explrFormlb3.Location = new System.Drawing.Point(1109, 110);
            this.explrFormlb3.Name = "explrFormlb3";
            this.explrFormlb3.Size = new System.Drawing.Size(38, 13);
            this.explrFormlb3.TabIndex = 7;
            this.explrFormlb3.Text = "Stdev:";
            // 
            // explrFormlb4
            // 
            this.explrFormlb4.AutoSize = true;
            this.explrFormlb4.Location = new System.Drawing.Point(1109, 140);
            this.explrFormlb4.Name = "explrFormlb4";
            this.explrFormlb4.Size = new System.Drawing.Size(30, 13);
            this.explrFormlb4.TabIndex = 8;
            this.explrFormlb4.Text = "Max:";
            // 
            // explrFormlb5
            // 
            this.explrFormlb5.AutoSize = true;
            this.explrFormlb5.Location = new System.Drawing.Point(1109, 170);
            this.explrFormlb5.Name = "explrFormlb5";
            this.explrFormlb5.Size = new System.Drawing.Size(27, 13);
            this.explrFormlb5.TabIndex = 9;
            this.explrFormlb5.Text = "Min:";
            // 
            // explrFormlb6
            // 
            this.explrFormlb6.AutoSize = true;
            this.explrFormlb6.Location = new System.Drawing.Point(1109, 200);
            this.explrFormlb6.Name = "explrFormlb6";
            this.explrFormlb6.Size = new System.Drawing.Size(59, 13);
            this.explrFormlb6.TabIndex = 10;
            this.explrFormlb6.Text = "Skewness:";
            // 
            // explrFormlb7
            // 
            this.explrFormlb7.AutoSize = true;
            this.explrFormlb7.Location = new System.Drawing.Point(1109, 230);
            this.explrFormlb7.Name = "explrFormlb7";
            this.explrFormlb7.Size = new System.Drawing.Size(47, 13);
            this.explrFormlb7.TabIndex = 11;
            this.explrFormlb7.Text = "Kurtosis:";
            // 
            // explrFormlb8
            // 
            this.explrFormlb8.AutoSize = true;
            this.explrFormlb8.Location = new System.Drawing.Point(1109, 260);
            this.explrFormlb8.Name = "explrFormlb8";
            this.explrFormlb8.Size = new System.Drawing.Size(102, 13);
            this.explrFormlb8.TabIndex = 12;
            this.explrFormlb8.Text = "Weibull Shape (est):";
            // 
            // explrFormlb9
            // 
            this.explrFormlb9.AutoSize = true;
            this.explrFormlb9.Location = new System.Drawing.Point(1109, 290);
            this.explrFormlb9.Name = "explrFormlb9";
            this.explrFormlb9.Size = new System.Drawing.Size(98, 13);
            this.explrFormlb9.TabIndex = 13;
            this.explrFormlb9.Text = "Weibull Scale (est):";
            // 
            // explrFormlb10
            // 
            this.explrFormlb10.AutoSize = true;
            this.explrFormlb10.Location = new System.Drawing.Point(1275, 80);
            this.explrFormlb10.Name = "explrFormlb10";
            this.explrFormlb10.Size = new System.Drawing.Size(0, 13);
            this.explrFormlb10.TabIndex = 14;
            // 
            // explrFormlb11
            // 
            this.explrFormlb11.AutoSize = true;
            this.explrFormlb11.Location = new System.Drawing.Point(1275, 110);
            this.explrFormlb11.Name = "explrFormlb11";
            this.explrFormlb11.Size = new System.Drawing.Size(0, 13);
            this.explrFormlb11.TabIndex = 15;
            // 
            // explrFormlb12
            // 
            this.explrFormlb12.AutoSize = true;
            this.explrFormlb12.Location = new System.Drawing.Point(1275, 140);
            this.explrFormlb12.Name = "explrFormlb12";
            this.explrFormlb12.Size = new System.Drawing.Size(0, 13);
            this.explrFormlb12.TabIndex = 16;
            // 
            // explrFormlb13
            // 
            this.explrFormlb13.AutoSize = true;
            this.explrFormlb13.Location = new System.Drawing.Point(1275, 170);
            this.explrFormlb13.Name = "explrFormlb13";
            this.explrFormlb13.Size = new System.Drawing.Size(0, 13);
            this.explrFormlb13.TabIndex = 17;
            // 
            // explrFormlb14
            // 
            this.explrFormlb14.AutoSize = true;
            this.explrFormlb14.Location = new System.Drawing.Point(1275, 200);
            this.explrFormlb14.Name = "explrFormlb14";
            this.explrFormlb14.Size = new System.Drawing.Size(0, 13);
            this.explrFormlb14.TabIndex = 18;
            // 
            // explrFormlb15
            // 
            this.explrFormlb15.AutoSize = true;
            this.explrFormlb15.Location = new System.Drawing.Point(1275, 230);
            this.explrFormlb15.Name = "explrFormlb15";
            this.explrFormlb15.Size = new System.Drawing.Size(0, 13);
            this.explrFormlb15.TabIndex = 19;
            // 
            // explrFormlb16
            // 
            this.explrFormlb16.AutoSize = true;
            this.explrFormlb16.Location = new System.Drawing.Point(1275, 260);
            this.explrFormlb16.Name = "explrFormlb16";
            this.explrFormlb16.Size = new System.Drawing.Size(0, 13);
            this.explrFormlb16.TabIndex = 20;
            // 
            // explrFormlb17
            // 
            this.explrFormlb17.AutoSize = true;
            this.explrFormlb17.Location = new System.Drawing.Point(1275, 290);
            this.explrFormlb17.Name = "explrFormlb17";
            this.explrFormlb17.Size = new System.Drawing.Size(59, 13);
            this.explrFormlb17.TabIndex = 21;
            this.explrFormlb17.Text = "Exploratory";
            // 
            // explrFormitrb
            // 
            this.explrFormitrb.AutoSize = true;
            this.explrFormitrb.Checked = true;
            this.explrFormitrb.Location = new System.Drawing.Point(63, 36);
            this.explrFormitrb.Name = "explrFormitrb";
            this.explrFormitrb.Size = new System.Drawing.Size(63, 17);
            this.explrFormitrb.TabIndex = 0;
            this.explrFormitrb.TabStop = true;
            this.explrFormitrb.Text = "Iterative";
            this.explrFormitrb.UseVisualStyleBackColor = true;
            this.explrFormitrb.CheckedChanged += new System.EventHandler(this.explrFormitrb_CheckedChanged);
            // 
            // explrFormwrb
            // 
            this.explrFormwrb.AutoSize = true;
            this.explrFormwrb.Location = new System.Drawing.Point(63, 13);
            this.explrFormwrb.Name = "explrFormwrb";
            this.explrFormwrb.Size = new System.Drawing.Size(60, 17);
            this.explrFormwrb.TabIndex = 1;
            this.explrFormwrb.Text = "Weibull";
            this.explrFormwrb.UseVisualStyleBackColor = true;
            this.explrFormwrb.CheckedChanged += new System.EventHandler(this.explrFormwrb_CheckedChanged);
            // 
            // explrFormpl
            // 
            this.explrFormpl.Controls.Add(this.explrFormitrb);
            this.explrFormpl.Controls.Add(this.explrFormwrb);
            this.explrFormpl.Location = new System.Drawing.Point(22, 331);
            this.explrFormpl.Name = "explrFormpl";
            this.explrFormpl.Size = new System.Drawing.Size(134, 60);
            this.explrFormpl.TabIndex = 24;
            // 
            // explrFormlb25
            // 
            this.explrFormlb25.AutoSize = true;
            this.explrFormlb25.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold);
            this.explrFormlb25.Location = new System.Drawing.Point(19, 315);
            this.explrFormlb25.Name = "explrFormlb25";
            this.explrFormlb25.Size = new System.Drawing.Size(58, 13);
            this.explrFormlb25.TabIndex = 25;
            this.explrFormlb25.Text = "Method:";
            // 
            // explrFormM
            // 
            this.explrFormM.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.explrFormM.BorderlineColor = System.Drawing.SystemColors.ButtonFace;
            chartArea3.AlignmentOrientation = ((System.Windows.Forms.DataVisualization.Charting.AreaAlignmentOrientations)((System.Windows.Forms.DataVisualization.Charting.AreaAlignmentOrientations.Vertical | System.Windows.Forms.DataVisualization.Charting.AreaAlignmentOrientations.Horizontal)));
            chartArea3.AxisX.MajorGrid.Enabled = false;
            chartArea3.AxisX.Title = "Transformation";
            chartArea3.AxisX.TitleFont = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            chartArea3.AxisY.MajorGrid.Enabled = false;
            chartArea3.AxisY.Title = "Asymmetry Measure";
            chartArea3.AxisY.TitleFont = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            chartArea3.BackSecondaryColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            chartArea3.BorderColor = System.Drawing.Color.Transparent;
            chartArea3.Name = "ChartArea1";
            this.explrFormM.ChartAreas.Add(chartArea3);
            legend3.Name = "Legend1";
            this.explrFormM.Legends.Add(legend3);
            this.explrFormM.Location = new System.Drawing.Point(12, 397);
            this.explrFormM.Name = "explrFormM";
            series3.ChartArea = "ChartArea1";
            series3.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series3.IsVisibleInLegend = false;
            series3.Legend = "Legend1";
            series3.Name = "Series1";
            this.explrFormM.Series.Add(series3);
            this.explrFormM.Size = new System.Drawing.Size(300, 258);
            this.explrFormM.TabIndex = 26;
            this.explrFormM.Text = "Data";
            // 
            // explrFormhist2
            // 
            this.explrFormhist2.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.explrFormhist2.BorderlineColor = System.Drawing.SystemColors.ButtonFace;
            chartArea4.AlignmentOrientation = ((System.Windows.Forms.DataVisualization.Charting.AreaAlignmentOrientations)((System.Windows.Forms.DataVisualization.Charting.AreaAlignmentOrientations.Vertical | System.Windows.Forms.DataVisualization.Charting.AreaAlignmentOrientations.Horizontal)));
            chartArea4.AxisX.IsLabelAutoFit = false;
            chartArea4.AxisX.LabelStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            chartArea4.AxisX.MajorGrid.Enabled = false;
            chartArea4.AxisX.Title = "Bin";
            chartArea4.AxisX.TitleFont = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            chartArea4.AxisY.IsLabelAutoFit = false;
            chartArea4.AxisY.LabelStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F);
            chartArea4.AxisY.MajorGrid.Enabled = false;
            chartArea4.AxisY.Title = "Frequency";
            chartArea4.AxisY.TitleFont = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            chartArea4.BackColor = System.Drawing.Color.White;
            chartArea4.BackSecondaryColor = System.Drawing.SystemColors.ButtonFace;
            chartArea4.Name = "ChartArea1";
            this.explrFormhist2.ChartAreas.Add(chartArea4);
            legend4.Name = "Legend1";
            this.explrFormhist2.Legends.Add(legend4);
            this.explrFormhist2.Location = new System.Drawing.Point(296, 397);
            this.explrFormhist2.Name = "explrFormhist2";
            series4.ChartArea = "ChartArea1";
            series4.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Area;
            series4.IsValueShownAsLabel = true;
            series4.IsVisibleInLegend = false;
            series4.Legend = "Legend1";
            series4.Name = "Series1";
            this.explrFormhist2.Series.Add(series4);
            this.explrFormhist2.Size = new System.Drawing.Size(300, 258);
            this.explrFormhist2.TabIndex = 27;
            this.explrFormhist2.Text = "chart1";
            // 
            // explrFormQQ
            // 
            this.explrFormQQ.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.explrFormQQ.BorderlineColor = System.Drawing.SystemColors.ButtonFace;
            chartArea5.AlignmentOrientation = ((System.Windows.Forms.DataVisualization.Charting.AreaAlignmentOrientations)((System.Windows.Forms.DataVisualization.Charting.AreaAlignmentOrientations.Vertical | System.Windows.Forms.DataVisualization.Charting.AreaAlignmentOrientations.Horizontal)));
            chartArea5.AxisX.IsLabelAutoFit = false;
            chartArea5.AxisX.MajorGrid.Enabled = false;
            chartArea5.AxisX.MajorTickMark.Enabled = false;
            chartArea5.AxisX.Title = "Normal (0,1)";
            chartArea5.AxisX.TitleFont = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            chartArea5.AxisY.IsLabelAutoFit = false;
            chartArea5.AxisY.LabelStyle.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            chartArea5.AxisY.MajorGrid.Enabled = false;
            chartArea5.AxisY.Title = "Data";
            chartArea5.AxisY.TitleFont = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            chartArea5.BackSecondaryColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            chartArea5.BorderColor = System.Drawing.SystemColors.ButtonFace;
            chartArea5.Name = "ChartArea1";
            this.explrFormQQ.ChartAreas.Add(chartArea5);
            legend5.Name = "Legend1";
            this.explrFormQQ.Legends.Add(legend5);
            this.explrFormQQ.Location = new System.Drawing.Point(580, 397);
            this.explrFormQQ.Name = "explrFormQQ";
            series5.ChartArea = "ChartArea1";
            series5.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Point;
            series5.IsVisibleInLegend = false;
            series5.Legend = "Legend1";
            series5.Name = "Series1";
            this.explrFormQQ.Series.Add(series5);
            this.explrFormQQ.Size = new System.Drawing.Size(300, 258);
            this.explrFormQQ.TabIndex = 28;
            this.explrFormQQ.Text = "Data";
            // 
            // explrFormstandardisebt
            // 
            this.explrFormstandardisebt.Location = new System.Drawing.Point(22, 200);
            this.explrFormstandardisebt.Name = "explrFormstandardisebt";
            this.explrFormstandardisebt.Size = new System.Drawing.Size(98, 36);
            this.explrFormstandardisebt.TabIndex = 29;
            this.explrFormstandardisebt.Text = "Further Standaridsation";
            this.explrFormstandardisebt.UseVisualStyleBackColor = true;
            this.explrFormstandardisebt.Click += new System.EventHandler(this.explrFormstandardisebt_Click);
            // 
            // explrFormMeans
            // 
            this.explrFormMeans.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.explrFormMeans.BorderlineColor = System.Drawing.SystemColors.ButtonFace;
            chartArea6.AlignmentOrientation = ((System.Windows.Forms.DataVisualization.Charting.AreaAlignmentOrientations)((System.Windows.Forms.DataVisualization.Charting.AreaAlignmentOrientations.Vertical | System.Windows.Forms.DataVisualization.Charting.AreaAlignmentOrientations.Horizontal)));
            chartArea6.AxisX.MajorGrid.Enabled = false;
            chartArea6.AxisX.Title = "Group";
            chartArea6.AxisX.TitleFont = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            chartArea6.AxisY.MajorGrid.Enabled = false;
            chartArea6.AxisY.Title = "Mean";
            chartArea6.AxisY.TitleFont = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            chartArea6.BackSecondaryColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            chartArea6.BorderColor = System.Drawing.Color.Transparent;
            chartArea6.Name = "ChartArea1";
            this.explrFormMeans.ChartAreas.Add(chartArea6);
            legend6.Name = "Legend1";
            this.explrFormMeans.Legends.Add(legend6);
            this.explrFormMeans.Location = new System.Drawing.Point(1067, 397);
            this.explrFormMeans.Name = "explrFormMeans";
            series6.ChartArea = "ChartArea1";
            series6.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series6.IsVisibleInLegend = false;
            series6.Legend = "Legend1";
            series6.Name = "Series1";
            this.explrFormMeans.Series.Add(series6);
            this.explrFormMeans.Size = new System.Drawing.Size(300, 258);
            this.explrFormMeans.TabIndex = 30;
            this.explrFormMeans.Text = "Data";
            // 
            // transformedlbl
            // 
            this.transformedlbl.AutoSize = true;
            this.transformedlbl.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.transformedlbl.Location = new System.Drawing.Point(896, 406);
            this.transformedlbl.Name = "transformedlbl";
            this.transformedlbl.Size = new System.Drawing.Size(125, 13);
            this.transformedlbl.TabIndex = 31;
            this.transformedlbl.Text = "Transformed Data";
            // 
            // transformedskewlbl
            // 
            this.transformedskewlbl.AutoSize = true;
            this.transformedskewlbl.Location = new System.Drawing.Point(896, 438);
            this.transformedskewlbl.Name = "transformedskewlbl";
            this.transformedskewlbl.Size = new System.Drawing.Size(59, 13);
            this.transformedskewlbl.TabIndex = 32;
            this.transformedskewlbl.Text = "Skewness:";
            // 
            // transformedkurtlbl
            // 
            this.transformedkurtlbl.AutoSize = true;
            this.transformedkurtlbl.Location = new System.Drawing.Point(896, 472);
            this.transformedkurtlbl.Name = "transformedkurtlbl";
            this.transformedkurtlbl.Size = new System.Drawing.Size(47, 13);
            this.transformedkurtlbl.TabIndex = 33;
            this.transformedkurtlbl.Text = "Kurtosis:";
            // 
            // transformedskewval
            // 
            this.transformedskewval.AutoSize = true;
            this.transformedskewval.Location = new System.Drawing.Point(1003, 438);
            this.transformedskewval.Name = "transformedskewval";
            this.transformedskewval.Size = new System.Drawing.Size(35, 13);
            this.transformedskewval.TabIndex = 34;
            this.transformedskewval.Text = "label1";
            // 
            // transformedkurtval
            // 
            this.transformedkurtval.AutoSize = true;
            this.transformedkurtval.Location = new System.Drawing.Point(1003, 472);
            this.transformedkurtval.Name = "transformedkurtval";
            this.transformedkurtval.Size = new System.Drawing.Size(35, 13);
            this.transformedkurtval.TabIndex = 35;
            this.transformedkurtval.Text = "label1";
            // 
            // standardisedlbl
            // 
            this.standardisedlbl.AutoSize = true;
            this.standardisedlbl.Font = new System.Drawing.Font("Verdana", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.standardisedlbl.Location = new System.Drawing.Point(896, 514);
            this.standardisedlbl.Name = "standardisedlbl";
            this.standardisedlbl.Size = new System.Drawing.Size(127, 13);
            this.standardisedlbl.TabIndex = 36;
            this.standardisedlbl.Text = "Standardised Data";
            // 
            // standardisedskewlbl
            // 
            this.standardisedskewlbl.AutoSize = true;
            this.standardisedskewlbl.Location = new System.Drawing.Point(896, 549);
            this.standardisedskewlbl.Name = "standardisedskewlbl";
            this.standardisedskewlbl.Size = new System.Drawing.Size(59, 13);
            this.standardisedskewlbl.TabIndex = 37;
            this.standardisedskewlbl.Text = "Skewness:";
            // 
            // standardisedkurtlbl
            // 
            this.standardisedkurtlbl.AutoSize = true;
            this.standardisedkurtlbl.Location = new System.Drawing.Point(896, 580);
            this.standardisedkurtlbl.Name = "standardisedkurtlbl";
            this.standardisedkurtlbl.Size = new System.Drawing.Size(47, 13);
            this.standardisedkurtlbl.TabIndex = 38;
            this.standardisedkurtlbl.Text = "Kurtosis:";
            // 
            // standardisedskewval
            // 
            this.standardisedskewval.AutoSize = true;
            this.standardisedskewval.Location = new System.Drawing.Point(1003, 549);
            this.standardisedskewval.Name = "standardisedskewval";
            this.standardisedskewval.Size = new System.Drawing.Size(35, 13);
            this.standardisedskewval.TabIndex = 39;
            this.standardisedskewval.Text = "label1";
            // 
            // standardisedkurtval
            // 
            this.standardisedkurtval.AutoSize = true;
            this.standardisedkurtval.Location = new System.Drawing.Point(1003, 580);
            this.standardisedkurtval.Name = "standardisedkurtval";
            this.standardisedkurtval.Size = new System.Drawing.Size(35, 13);
            this.standardisedkurtval.TabIndex = 40;
            this.standardisedkurtval.Text = "label1";
            // 
            // explrFormSavebt
            // 
            this.explrFormSavebt.Location = new System.Drawing.Point(22, 260);
            this.explrFormSavebt.Name = "explrFormSavebt";
            this.explrFormSavebt.Size = new System.Drawing.Size(98, 36);
            this.explrFormSavebt.TabIndex = 41;
            this.explrFormSavebt.Text = "Save Data";
            this.explrFormSavebt.UseVisualStyleBackColor = true;
            this.explrFormSavebt.Click += new System.EventHandler(this.explrFormSavebt_Click);
            // 
            // explrForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.ClientSize = new System.Drawing.Size(1370, 667);
            this.Controls.Add(this.explrFormSavebt);
            this.Controls.Add(this.standardisedkurtval);
            this.Controls.Add(this.standardisedskewval);
            this.Controls.Add(this.standardisedkurtlbl);
            this.Controls.Add(this.standardisedskewlbl);
            this.Controls.Add(this.standardisedlbl);
            this.Controls.Add(this.transformedkurtval);
            this.Controls.Add(this.transformedskewval);
            this.Controls.Add(this.transformedkurtlbl);
            this.Controls.Add(this.transformedskewlbl);
            this.Controls.Add(this.transformedlbl);
            this.Controls.Add(this.explrFormMeans);
            this.Controls.Add(this.explrFormstandardisebt);
            this.Controls.Add(this.explrFormQQ);
            this.Controls.Add(this.explrFormhist2);
            this.Controls.Add(this.explrFormM);
            this.Controls.Add(this.explrFormlb25);
            this.Controls.Add(this.explrFormpl);
            this.Controls.Add(this.explrFormlb17);
            this.Controls.Add(this.explrFormlb16);
            this.Controls.Add(this.explrFormlb15);
            this.Controls.Add(this.explrFormlb14);
            this.Controls.Add(this.explrFormlb13);
            this.Controls.Add(this.explrFormlb12);
            this.Controls.Add(this.explrFormlb11);
            this.Controls.Add(this.explrFormlb10);
            this.Controls.Add(this.explrFormlb9);
            this.Controls.Add(this.explrFormlb8);
            this.Controls.Add(this.explrFormlb7);
            this.Controls.Add(this.explrFormlb6);
            this.Controls.Add(this.explrFormlb5);
            this.Controls.Add(this.explrFormlb4);
            this.Controls.Add(this.explrFormlb3);
            this.Controls.Add(this.explrFormlb2);
            this.Controls.Add(this.explrFormlb1);
            this.Controls.Add(this.explrhist1);
            this.Controls.Add(this.explrTS);
            this.Controls.Add(this.explrlb);
            this.Controls.Add(this.explrbt);
            this.Controls.Add(this.explrdgv1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MinimizeBox = false;
            this.Name = "explrForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Exploratory";
            this.Load += new System.EventHandler(this.explrForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.explrdgv1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.explrTS)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.explrhist1)).EndInit();
            this.explrFormpl.ResumeLayout(false);
            this.explrFormpl.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.explrFormM)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.explrFormhist2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.explrFormQQ)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.explrFormMeans)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button explrbt;
        private System.Windows.Forms.ListBox explrlb;
        private System.Windows.Forms.DataGridView explrdgv1;
        private System.Windows.Forms.DataVisualization.Charting.Chart explrTS;
        private System.Windows.Forms.DataVisualization.Charting.Chart explrhist1;
        private System.Windows.Forms.Label explrFormlb1;
        private System.Windows.Forms.Label explrFormlb2;
        private System.Windows.Forms.Label explrFormlb3;
        private System.Windows.Forms.Label explrFormlb4;
        private System.Windows.Forms.Label explrFormlb5;
        private System.Windows.Forms.Label explrFormlb6;
        private System.Windows.Forms.Label explrFormlb7;
        private System.Windows.Forms.Label explrFormlb8;
        private System.Windows.Forms.Label explrFormlb9;
        private System.Windows.Forms.Label explrFormlb10;
        private System.Windows.Forms.Label explrFormlb11;
        private System.Windows.Forms.Label explrFormlb12;
        private System.Windows.Forms.Label explrFormlb13;
        private System.Windows.Forms.Label explrFormlb14;
        private System.Windows.Forms.Label explrFormlb15;
        private System.Windows.Forms.Label explrFormlb16;
        private System.Windows.Forms.Label explrFormlb17;
        private System.Windows.Forms.RadioButton explrFormwrb;
        private System.Windows.Forms.RadioButton explrFormitrb;
        private System.Windows.Forms.Panel explrFormpl;
        private System.Windows.Forms.Label explrFormlb25;
        private System.Windows.Forms.DataVisualization.Charting.Chart explrFormM;
        private System.Windows.Forms.DataVisualization.Charting.Chart explrFormhist2;
        private System.Windows.Forms.DataVisualization.Charting.Chart explrFormQQ;
        private System.Windows.Forms.Button explrFormstandardisebt;
        private System.Windows.Forms.DataVisualization.Charting.Chart explrFormMeans;
        private System.Windows.Forms.Label transformedlbl;
        private System.Windows.Forms.Label transformedskewlbl;
        private System.Windows.Forms.Label transformedkurtlbl;
        private System.Windows.Forms.Label transformedskewval;
        private System.Windows.Forms.Label transformedkurtval;
        private System.Windows.Forms.Label standardisedlbl;
        private System.Windows.Forms.Label standardisedskewlbl;
        private System.Windows.Forms.Label standardisedkurtlbl;
        private System.Windows.Forms.Label standardisedskewval;
        private System.Windows.Forms.Label standardisedkurtval;
        private System.Windows.Forms.Button explrFormSavebt;
    }
}