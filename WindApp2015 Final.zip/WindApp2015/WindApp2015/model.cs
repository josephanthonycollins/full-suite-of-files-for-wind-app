﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WindApp2015
{
    //Class which will be used to maintain the output for any ARIMA/ARCH/GARCH model
    class model
    {
        //Yule Walker, Hannan Rissanen, Maximum Likelihood etc
        private string type;

        public string Type
        {
            get { return type; }
            set { type = value; }
        }

        //number of AR parameters
        private int p;

        public int P
        {
            get { return p; }
            set { p = value; }
        }

        //number of MA parameters
        private int q;

        public int Q
        {
            get { return q; }
            set { q = value; }
        }


        //number of differences i.e. the I in an ARIMA model
        private int d;

        public int D
        {
            get { return d; }
            set { d = value; }
        }

        //AIC value for the model
        private double aic;

        public double Aic
        {
            get { return aic; }
            set { aic = value; }
        }

        //BIC value for the model
        private double bic;

        public double Bic
        {
            get { return bic; }
            set { bic = value; }
        }

        //parameter fits for the model
        private List<double> parameters = new List<double>();

        public List<double> Parameters
        {
            get { return parameters; }
            set { parameters = value; }
        }

        //variance for the fitted model i.e. sigma hat squared
        private double variance;

        public double Variance
        {
            get { return variance; }
            set { variance = value; }
        }

        //sum of the squared residuals for the model object
        private double sumsquaredresiduals;

        public double Sumsquaredresiduals
        {
            get { return sumsquaredresiduals; }
            set { sumsquaredresiduals = value; }
        }

        //residuals from the fitted model
        private List<double> residuals = new List<double>();

        public List<double> Residuals
        {
            get { return residuals; }
            set { residuals = value; }
        }

        //auctocorrelation function for the residuals
        private List<double> acfresiduals = new List<double>();

        public List<double> Acfresiduals
        {
            get { return acfresiduals; }
            set { acfresiduals = value; }
        }

        //if the underlying data was transformed, this variable keeps track of the type of transformation i.e. Iterative, Weibull, ""
        private string transformtype;

        public string Transformtype
        {
            get { return transformtype; }
            set { transformtype = value; }
        }

        //if the underlying data was transformed, this variable keeps track of the shape or the power of the transform
        private double transformshape;

        public double Transformshape
        {
            get { return transformshape; }
            set { transformshape = value; }
        }

        //if the underlying data was transformed, this variable keeps track of the scale parameter if the transform was Weibull
        private double transformscale;

        public double Transformscale
        {
            get { return transformscale; }
            set { transformscale = value; }
        }

        //number of ARCH p parameters
        private int archp;

        public int archP
        {
            get { return archp; }
            set { archp = value; }
        }

        //number of ARCH q parameters
        private int archq;

        public int archQ
        {
            get { return archq; }
            set { archq = value; }
        }

        //arch/garch parameters 
        private List<double> archparameters = new List<double>();

        public List<double> archParameters
        {
            get { return archparameters; }
            set { archparameters = value; }
        }

        //arch AIC value
        private double archaic;

        public double archAic
        {
            get { return archaic; }
            set { archaic = value; }
        }

        //In the model Y(t)=X(t)B + e(t), e(t) is (h(t))^0.5 * v(t)
        //archwhitenoise will hold the estimate of the v(t) process
        //See Chapter 5, equation 5.3 in the accompanying manual
        private List<double> archwhitenoise = new List<double>();

        public List<double> archWhitenoise
        {
            get { return archwhitenoise; }
            set { archwhitenoise = value; }
        }

        //auctocorrelation function for the residuals
        private List<double> archacfwhitenoise = new List<double>();

        public List<double> archacfWhitenoise
        {
            get { return archacfwhitenoise; }
            set { archacfwhitenoise = value; }
        }

        //variable to indicate whether or not the mean needs to be subtracted from each data point
        private bool subtractmean;

        public bool Subtractmean
        {
            get { return subtractmean; }
            set { subtractmean = value; }
        }

        //constructor
        public model(string t, int p, int q, int d, double aic, double bic, List<double> parameters,List<double> residuals, double v, List<double> acf,double ss, string transformtype, double transformshape, double transformscale,int archq, int archp, List<double> archparameters, double archaic, bool subtractmean)
        {
            this.Type = t;
            this.P = p;
            this.Q = q;
            this.D = d;
            this.Aic = aic;
            this.Bic = bic;
            int sizeparameters = parameters.Count();
            this.Parameters.Clear();
            for (int i = 0; i < sizeparameters; i++)
                this.Parameters.Add(parameters[i]);
            int sizeresiduals = residuals.Count();
            this.Residuals.Clear();
            for (int i = 0; i < sizeresiduals; i++)
                this.Residuals.Add(residuals[i]);
            this.Variance = v;
            int sizeacfresiduals = acf.Count();
            this.Acfresiduals.Clear();
            for (int i = 0; i < sizeacfresiduals; i++)
                this.Acfresiduals.Add(acf[i]);
            this.Sumsquaredresiduals = ss;
            this.Transformtype = transformtype;
            this.Transformshape = transformshape;
            this.Transformscale = transformscale;
            this.archP = archp;
            this.archQ = archq;
            this.archAic = archaic;
            int sizearchparameters = archparameters.Count();
            this.archParameters.Clear();
            for (int i = 0; i < sizearchparameters; i++)
                this.archParameters.Add(archparameters[i]);
            this.Subtractmean = subtractmean;      
        }

        //constructor for ARCH/GARCH models
        public model(string t, int p, int q, int d, double aic, double bic, List<double> parameters, List<double> residuals, double v, List<double> acf, double ss, string transformtype, double transformshape, double transformscale, int archq, int archp, List<double> archparameters, double archaic, List<double> archwhitenoise, List<double> archacfwhitenoise, bool subtractmean)
        {
            this.Type = t;
            this.P = p;
            this.Q = q;
            this.D = d;
            this.Aic = aic;
            this.Bic = bic;
            int sizeparameters = parameters.Count();
            this.Parameters.Clear();
            for (int i = 0; i < sizeparameters; i++)
                this.Parameters.Add(parameters[i]);
            int sizeresiduals = residuals.Count();
            this.Residuals.Clear();
            for (int i = 0; i < sizeresiduals; i++)
                this.Residuals.Add(residuals[i]);
            this.Variance = v;
            int sizeacfresiduals = acf.Count();
            this.Acfresiduals.Clear();
            for (int i = 0; i < sizeacfresiduals; i++)
                this.Acfresiduals.Add(acf[i]);
            this.Sumsquaredresiduals = ss;
            this.Transformtype = transformtype;
            this.Transformshape = transformshape;
            this.Transformscale = transformscale;
            this.archP = archp;
            this.archQ = archq;
            this.archAic = archaic;
            int sizearchparameters = archparameters.Count();
            this.archParameters.Clear();
            for (int i = 0; i < sizearchparameters; i++)
                this.archParameters.Add(archparameters[i]);
            int sizearchwhitenoise = archwhitenoise.Count();
            this.archWhitenoise.Clear();
            for (int i = 0; i < sizearchwhitenoise; i++)
                this.archWhitenoise.Add(archwhitenoise[i]);
            int sizearchacfwhitenoise = archacfwhitenoise.Count();
            this.archacfWhitenoise.Clear();
            for (int i = 0; i < sizearchacfwhitenoise; i++)
                this.archacfWhitenoise.Add(archacfwhitenoise[i]);
            this.Subtractmean = subtractmean;      
        }


    }
}
