﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WindApp2015
{
    //form to helping with standardising the data
    //the form may also be called by other MDI child forms

    public partial class standardiseForm : Form
    {
        //number of rows in the spreadsheet
        private int n1;

        public int N1
        {
            get { return n1; }
            set { n1 = value; }
        }

        //number of columns in the spreadsheet
        private int m1;

        public int M1
        {
            get { return m1; }
            set { m1 = value; }
        }

        public standardiseForm()
        {
            InitializeComponent();
        }

        private void standardisetxtbrows_Validated(object sender, EventArgs e)
        {
            int d;
            bool bTest = int.TryParse(standardisetxtbrows.Text, out d);
            if ((bTest == true) && (d <= this.N1) && (d > 0))
                this.errorProvider1.SetError(standardisetxtbrows, "");
            else
            {
                string str="This value must be an integer between 1 and "+this.N1;
                this.errorProvider1.SetError(standardisetxtbrows, str);
            }
       }

        private void standardisetxtbcols_Validated(object sender, EventArgs e)
        {
            int d;
            bool bTest = int.TryParse(standardisetxtbcols.Text, out d);
            if ((bTest == true) && (d <= this.M1) && (d > 0))
                this.errorProvider1.SetError(standardisetxtbcols, "");
            else
            {
                string str = "This value must be an integer between 1 and " + this.M1;
                this.errorProvider1.SetError(standardisetxtbcols, str);

            }
        }

        private void standardiseFormbtOk_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.OK;
            if ((errorProvider1.GetError(standardisetxtbcols).Length != 0) || (errorProvider1.GetError(standardisetxtbrows).Length != 0))
            {
                MessageBox.Show("Input must be correct before continuing");
                return;
            }
            this.Close();
        }


        //end of standardise class
    }
}
