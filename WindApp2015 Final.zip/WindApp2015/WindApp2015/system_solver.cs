﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WindApp2015
{
    //system solver class, i.e. matrix inverse, solving simulataneous equations etc
    class system_solver
    {
        //Solve a tridiagonal system using the Thomas Algorithm

        public double[] ThomasAlg(double[] aa, double[] bb, double[] cc, double[] dd)
        {
            //note that first element in the "aa" array should be 0
            //similarly, the last element in the "cc" array should be 0
            int size = bb.GetLength(0);
            double[] cpr = new double[size];
            double[] dpr = new double[size];
            double[] sol = new double[size];

            //start populating the cpr array
            cpr[0] = cc[0] / bb[0];
            for (int i = 1; i <= size - 2; i++)
            {
                cpr[i] = cc[i] / (bb[i] - cpr[i - 1] * aa[i]);

            }

            //start populating the dpr array
            dpr[0] = dd[0] / bb[0];
            for (int i = 1; i <= size - 1; i++)
            {
                dpr[i] = (dd[i] - dpr[i - 1] * aa[i]) / (bb[i] - cpr[i - 1] * aa[i]);

            }

            //start populating the sol array
            for (int i = size - 1; i >= 0; i--)
            {
                if (i == size - 1)
                {
                    sol[i] = dpr[i];
                }
                else
                {
                    sol[i] = dpr[i] - cpr[i] * sol[i + 1];
                }
            }

            return sol;
        }

        // compute the LU decomposition of a matrix a using Crout's algorithm
        // a is written over by this function
        // upon output a contains L and U
        public void ludcmp(double[,] a, int[] indx, int size, ref double d)
        {
            /********************************NOT SURE HOW d is meant to be used******/
            int i = 0, imax = 0, j = 0, k = 0;
            double big = 0, dum = 0, sum = 0, temp = 0;
            double TINY = (1.0e-15);
            // create a vector for storing values for scaling
            double[] vv = new double[size + 1];

            /*******NOT SURE IF THIS IS WHAT THE C++ code is trying to do***********/
            // This keeps track any row interchanges that are made
            d = 1.0;

            // store scaling values in vv
            /*INDEXING CHANGE HERE*/
            for (i = 0; i < size; i++)
            {
                big = 0.0;
                /*INDEXING CHANGE HERE*/
                for (j = 0; j < size; j++)
                {
                    if ((temp = Math.Abs(a[i, j])) > big)
                    {
                        big = temp;
                    }
                }
                if (big == 0.0)
                {
                    Console.WriteLine("Singular matrix in routine LUDCMP");
                }

                vv[i] = 1.0 / big;
            }

            /*INDEXING CHANGE HERE*/
            for (j = 0; j < size; j++)
            {
                // Start applying Crout's algorithm for computing the LU Decomposition
                /*INDEXING CHANGE HERE*/
                for (i = 0; i < j; i++)
                {
                    sum = a[i, j];
                    for (k = 0; k < i; k++)
                    {
                        sum -= a[i, k] * a[k, j];
                    }
                    a[i, j] = sum;
                }

                // Find the pivot element
                big = 0.0;
                /*INDEXING CHANGE HERE*/
                for (i = j; i < size; i++)
                {
                    sum = a[i, j];
                    /*INDEXING CHANGE HERE*/
                    for (k = 0; k < j; k++)
                    {
                        sum -= a[i, k] * a[k, j];
                    }
                    a[i, j] = sum;
                    if ((dum = vv[i] * Math.Abs(sum)) >= big)
                    {
                        big = dum;
                        imax = i;
                    }
                }

                // Simulate a row swap if required
                if (j != imax)
                {
                    /*INDEXING CHANGE HERE*/
                    for (k = 0; k < size; k++)
                    {
                        dum = a[imax, k];
                        a[imax, k] = a[j, k];
                        a[j, k] = dum;
                    }
                    d = -(d);
                    vv[imax] = vv[j];
                }


                indx[j] = imax;

                if (a[j, j] == 0.0)
                {
                    a[j, j] = TINY;
                }

                // Scale a row by the pivot element
                if (j != size)
                {
                    dum = 1.0 / (a[j, j]);
                    /*INDEXING CHANGE HERE*/
                    for (i = j + 1; i < size; i++)
                    {
                        a[i, j] *= dum;
                    }
                }

                //end of Crout algorithm element
            }

            //end of method
        }

        //method to determine the inverse
        public double[,] find_inverse(double[,] a, int size)
        {
            // Perform the steps necessary to compute the inverse of the matrix A
            // A copy of a is made
            // The lu decomposition of a is stored in this array
            // the inverse of a is returned by this function

            // This variable is used to keep track of row interchanges inside the lu decomposition function
            double dtmp = 0.0;
            double d = 0;
            d = dtmp;

            // Create the necessary arrays
            int[] indx = new int[size + 1];
            double[] col = new double[size + 1];

            // Declare matrices to hold the data
            double[,] lua = new double[size + 1, size + 1];
            double[,] ainv = new double[size + 1, size + 1];

            // copy a into lua, then compute its lu decomposition
            for (int i = 0; i < size; i++)
            {
                indx[i] = 0;
                for (int j = 0; j < size; j++)
                {
                    lua[i, j] = a[i, j];
                }
            }

            // compute the lu decomposition of a, this is stored in lua
            ludcmp(lua, indx, size, ref d);

            luinv(lua, ainv, col, indx, size);

            //Joe Collins inserted this additional code here
            double[,] temp = new double[size, size];
            for (int i = 0; i < size; i++)
                for (int j = 0; j < size; j++)
                    temp[i, j] = ainv[i, j];

            return temp;
        }

        public void luinv(double[,] a, double[,] y, double[] col, int[] indx, int size)
        {
            // find the inverse of a matrix from its LU Decomposition
            // inverting by solving a.x=col, where col is a unit vector
            int i, j;
            /*INDEXING CHANGE HERE*/
            for (j = 0; j < size; j++)
            {
                /*INDEXING CHANGE HERE*/
                for (i = 0; i < size; i++)
                {
                    col[i] = 0.0;
                }

                col[j] = 1.0;
                lubksb(a, indx, col, size);
                /*INDEXING CHANGE HERE*/
                for (i = 0; i < size; i++)
                {
                    y[i, j] = col[i];
                }
            }

            //end of method
        }

        public void lubksb(double[,] a, int[] indx, double[] b, int size)
        {
            // solve the system of linear equations a.x = b by LU Decomposition
            // a is assumed to contain its LU decomposition
            // indx contains any row swap information
            // b contains the solution of the system of equations upon output

            int i = 0, ii = 0, ip = 0, j = 0;
            double sum = 0;

            // Forward substitution to solve L.y = b
            /*INDEX CHANGE HERE*/
            for (i = 0; i < size; i++)
            {

                ip = indx[i];
                sum = b[ip];
                b[ip] = b[i];
                /*LOGICAL CHANGE HERE, ORIGINALLY IT WAS if(ii)*/
                if (ii >= 0)
                {
                    for (j = ii; j <= i - 1; j++)
                    {
                        sum -= a[i, j] * b[j];
                    }
                }
                /*LOGICAL CHANGE HERE, originally it was if(sum)*/
                else if (sum != 0)
                {
                    ii = i;
                }
                b[i] = sum;
            }

            // Back substitution to solve U.x = y
            /*INDEX CHANGE HERE*/
            for (i = size - 1; i >= 0; i--)
            {
                /*INDEX CHANGE HERE*/
                sum = b[i];
                for (j = i + 1; j <= size; j++)
                {
                    sum -= a[i, j] * b[j];
                }
                // store the solution in b
                b[i] = sum / (a[i, i]);
            }

            //END OF METHOD
        }

        public double[] solve_system(double[,] a, double[] b, int size)
        {
            // Sovle the linear system A.x = b using LU Decomposition

            // This variable is used to keep track of row interchanges inside the lu decomposition function
            //double dtmp = 0.0;
            double d = 0;

            // Create the necessary arrays
            int[] indx = new int[size + 1];
            double[] sol = new double[size + 1];

            // Declare matrices to hold the data
            double[,] lua = new double[size + 1, size + 1];

            // copy a into lua, then compute its lu decomposition
            for (int i = 0; i < size; i++)
            {
                indx[i] = 0;
                sol[i] = b[i];
                for (int j = 0; j < size; j++)
                {
                    lua[i, j] = a[i, j];
                }
            }

            // compute the lu decomposition of a, this is stored in lua
            ludcmp(lua, indx, size, ref d);

            // solve the system using the backsubstitution
            lubksb(lua, indx, sol, size);

            return sol;
            //end of method
        }

        public void ludet(double[,] a, ref double d, int size)
        {
            // compute the determinant of a matrix from its LU decomposition
            int j = 0;
            for (j = 0; j < size; j++)
            {
                d *= a[j, j];
            }
        }

        //end of class        
    }

    //end of Namespace
}
